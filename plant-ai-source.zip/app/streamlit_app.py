import importlib
from html import escape
from pathlib import Path
from typing import Dict, Optional

import streamlit as st
from PIL import Image

import src.inference.pipeline as pipeline_module
from src.services.history import build_plant_key, compare_records, latest_record_for_plant, records_for_plant, save_analysis_record
from src.services.recommendation import _disease_category, generate_recommendation
from src.services.risk import calculate_risk
from src.utils.config import load_config


st.set_page_config(page_title="PlantAI 시설 작물 진단", layout="centered")


def _inject_style() -> None:
    st.markdown(
        """
        <style>
        :root {
            --green: #16a34a;
            --green-dark: #15803d;
            --green-soft: #ecfdf3;
            --blue: #2563eb;
            --ink: #17212b;
            --muted: #667085;
            --line: #dfe7df;
            --panel: #ffffff;
            --page: #f6f8f5;
        }

        .stApp {
            background: var(--page);
        }

        .block-container {
            max-width: 980px;
            padding-top: 36px;
            padding-bottom: 60px;
        }

        h1, h2, h3, p, label, span, div {
            letter-spacing: 0;
        }

        h1 {
            color: var(--ink);
            font-size: 34px !important;
            font-weight: 820 !important;
            line-height: 1.24 !important;
            margin-bottom: 10px !important;
        }

        h2, h3 {
            color: var(--ink);
            font-weight: 780 !important;
        }

        .site-header {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 26px 28px;
            margin-bottom: 18px;
        }

        .brand-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 20px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--ink);
            font-weight: 820;
            font-size: 17px;
        }

        .brand-mark {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            background: var(--green);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 900;
        }

        .model-pill {
            color: var(--green-dark);
            background: var(--green-soft);
            border: 1px solid #bbf7d0;
            border-radius: 999px;
            padding: 8px 12px;
            font-size: 13px;
            font-weight: 760;
            white-space: nowrap;
        }

        .hero-title {
            color: var(--ink);
            font-size: 34px;
            font-weight: 840;
            line-height: 1.25;
            margin-bottom: 10px;
        }

        .hero-copy {
            color: var(--muted);
            font-size: 16px;
            line-height: 1.65;
            max-width: 680px;
        }

        .stat-strip {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 10px;
            margin-top: 22px;
        }

        .stat-item {
            background: #f9fbfa;
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 14px 16px;
        }

        .stat-value {
            color: var(--green-dark);
            font-size: 18px;
            font-weight: 820;
            margin-bottom: 4px;
        }

        .stat-label {
            color: var(--muted);
            font-size: 13px;
            font-weight: 650;
        }

        .section-label {
            color: var(--muted);
            font-size: 13px;
            font-weight: 780;
            margin: 24px 0 8px;
        }

        .upload-guide {
            background: var(--panel);
            border: 1px dashed #9bd7ad;
            border-radius: 8px;
            padding: 22px 24px;
            margin: 14px 0 18px;
            color: var(--muted);
            line-height: 1.6;
        }

        .result-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
            margin: 12px 0 18px;
        }

        .result-card {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 22px;
            border-top: 4px solid var(--green);
        }

        .result-card.secondary {
            border-top-color: var(--blue);
        }

        .result-title {
            color: var(--muted);
            font-size: 13px;
            font-weight: 760;
            margin-bottom: 10px;
        }

        .result-value {
            color: var(--ink);
            font-size: 27px;
            font-weight: 840;
            line-height: 1.25;
            margin-bottom: 8px;
            word-break: keep-all;
        }

        .confidence-track {
            height: 8px;
            background: #edf2ef;
            border-radius: 999px;
            overflow: hidden;
            margin-top: 14px;
        }

        .confidence-fill {
            height: 100%;
            background: var(--green);
            border-radius: 999px;
        }

        .confidence-fill.blue {
            background: var(--blue);
        }

        .result-confidence {
            color: var(--muted);
            font-size: 13px;
            font-weight: 720;
        }

        .list-panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 20px 22px;
            margin-top: 14px;
        }

        .list-title {
            color: var(--ink);
            font-size: 17px;
            font-weight: 820;
            margin-bottom: 10px;
        }

        .list-panel ul {
            margin: 0;
            padding-left: 19px;
        }

        .list-panel li {
            color: var(--ink);
            margin: 8px 0;
            line-height: 1.55;
        }

        .risk-panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 20px 22px;
            margin: 14px 0;
        }

        .risk-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 12px;
        }

        .risk-level {
            color: var(--ink);
            font-size: 22px;
            font-weight: 840;
        }

        .risk-score {
            color: var(--muted);
            font-size: 14px;
            font-weight: 760;
        }

        .risk-meter {
            height: 10px;
            border-radius: 999px;
            overflow: hidden;
            background: #edf2ef;
            margin-bottom: 12px;
        }

        .risk-fill {
            height: 100%;
            border-radius: 999px;
        }

        .risk-fill.low {
            background: var(--green);
        }

        .risk-fill.watch {
            background: #f59e0b;
        }

        .risk-fill.high {
            background: #dc2626;
        }

        .risk-message,
        .compare-message {
            color: var(--ink);
            line-height: 1.55;
            margin: 0;
        }

        .meta-line {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.55;
            margin-top: 8px;
        }

        .compare-panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 20px 22px;
            margin-top: 14px;
        }

        .compare-title {
            color: var(--ink);
            font-size: 17px;
            font-weight: 820;
            margin-bottom: 10px;
        }

        div[data-testid="stFileUploader"] {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 18px;
        }

        div[data-testid="stImage"] img {
            border-radius: 8px;
            border: 1px solid var(--line);
        }

        .stButton button {
            width: 100%;
            height: 50px;
            border-radius: 8px;
            background: var(--green);
            border: 0;
            color: white;
            font-weight: 780;
            font-size: 16px;
        }

        .stButton button:hover {
            background: var(--green-dark);
            color: white;
            border: 0;
        }

        div[data-testid="stExpander"] {
            border: 1px solid var(--line);
            border-radius: 8px;
            background: var(--panel);
        }

        @media (max-width: 720px) {
            .block-container {
                padding-top: 24px;
            }

            .brand-row {
                align-items: flex-start;
                flex-direction: column;
            }

            .stat-strip,
            .result-grid {
                grid-template-columns: 1fr;
            }

            .hero-title {
                font-size: 28px;
            }

            .result-value {
                font-size: 22px;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


@st.cache_resource
def load_pipeline(config_path: str, config_mtime: float, pipeline_mtime: float):
    reloaded_pipeline = importlib.reload(pipeline_module)
    return reloaded_pipeline.PlantDiagnosisPipeline(config_path=config_path)


def _check_model_files(config_path: str) -> Optional[str]:
    try:
        cfg = load_config(config_path)
    except Exception as e:
        return f"Failed to read config: {e}"

    missing = []
    for key in ["species", "disease"]:
        ckpt = cfg.get(key, {}).get("checkpoint_path")
        cmap = cfg.get(key, {}).get("class_map_path")
        if not ckpt or not Path(ckpt).exists():
            missing.append(f"{key}.checkpoint_path -> {ckpt}")
        if cmap and not Path(cmap).exists():
            missing.append(f"{key}.class_map_path -> {cmap}")

    if missing:
        return "Missing model files:\n- " + "\n- ".join(missing)
    return None


def _default_weather() -> Dict:
    return {
        "location": "default",
        "temperature_c": 20.0,
        "humidity": 55,
        "precipitation_mm": 0.0,
        "weather_main": "N/A",
        "weather_description": "N/A",
        "cloudiness": None,
        "sunlight_level": "medium",
    }


def _render_header() -> None:
    st.markdown(
        """
        <div class="site-header">
            <div class="brand-row">
                <div class="brand">
                    <span class="brand-mark">P</span>
                    <span>PlantAI Diagnosis</span>
                </div>
                <div class="model-pill">EfficientNet-B0 기반 분석</div>
            </div>
            <div class="hero-title">시설 작물 이미지를 분석해<br>작물과 질병을 빠르게 진단합니다</div>
            <div class="hero-copy">
                업로드한 이미지를 기반으로 작물과 질병 상태를 분류하고,
                신뢰도와 관리 추천을 함께 제공합니다.
            </div>
            <div class="stat-strip">
                <div class="stat-item">
                    <div class="stat-value">시설 작물 분류</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">질병 및 정상 분류</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">이미지 기반 자동 진단</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _show_top_predictions(title: str, result: Dict) -> None:
    with st.expander(title):
        for item in result.get("top_k", []):
            raw = item.get("raw_label", "")
            label = item.get("label", raw)
            conf = float(item.get("confidence", 0.0)) * 100
            st.write(f"- {label} `{raw}`: **{conf:.2f}%**")


def _render_result_cards(result: Dict) -> None:
    species_label = escape(str(result["species"]["label"]))
    species_conf = result["species"]["confidence"] * 100
    disease_label = escape(str(result["disease"]["label"]))
    disease_conf = result["disease"]["confidence"] * 100
    species_width = max(0, min(100, species_conf))
    disease_width = max(0, min(100, disease_conf))

    st.markdown(
        f"""
        <div class="result-grid">
            <div class="result-card">
                <div class="result-title">작물 예측</div>
                <div class="result-value">{species_label}</div>
                <div class="result-confidence">신뢰도 {species_conf:.2f}%</div>
                <div class="confidence-track">
                    <div class="confidence-fill" style="width: {species_width:.2f}%"></div>
                </div>
            </div>
            <div class="result-card secondary">
                <div class="result-title">질병 예측</div>
                <div class="result-value">{disease_label}</div>
                <div class="result-confidence">신뢰도 {disease_conf:.2f}%</div>
                <div class="confidence-track">
                    <div class="confidence-fill blue" style="width: {disease_width:.2f}%"></div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_list_panel(title: str, items) -> None:
    rendered_items = "".join(f"<li>{escape(str(item))}</li>" for item in items)
    st.markdown(
        f"""
        <div class="list-panel">
            <div class="list-title">{escape(title)}</div>
            <ul>{rendered_items}</ul>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _risk_fill_class(level: str) -> str:
    if level == "높음":
        return "high"
    if level == "주의":
        return "watch"
    return "low"


def _render_risk_panel(risk: Dict) -> None:
    score = int(risk.get("score", 0))
    level = escape(str(risk.get("level", "unknown")))
    message = escape(str(risk.get("message", "")))
    factors = ", ".join(str(item) for item in risk.get("factors", []))
    fill_class = _risk_fill_class(risk.get("level", ""))

    st.markdown(
        f"""
        <div class="risk-panel">
            <div class="risk-row">
                <div class="risk-level">위험도 {level}</div>
                <div class="risk-score">{score}/100</div>
            </div>
            <div class="risk-meter">
                <div class="risk-fill {fill_class}" style="width: {max(0, min(100, score))}%"></div>
            </div>
            <p class="risk-message">{message}</p>
            <div class="meta-line">반영 요소: {escape(factors)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _format_confidence(value: float) -> str:
    return f"{value * 100:.1f}%"


def _render_history_comparison(comparison: Dict, current_record: Dict) -> None:
    st.markdown('<div class="section-label">시계열 히스토리</div>', unsafe_allow_html=True)

    if not comparison.get("has_previous"):
        st.markdown(
            f"""
            <div class="compare-panel">
                <div class="compare-title">첫 기록 저장됨</div>
                <p class="compare-message">{escape(comparison["summary"])}</p>
                <div class="meta-line">현재 위험도: {current_record["risk_level"]} {current_record["risk_score"]}/100</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    previous = comparison["previous"]
    disease_delta = comparison["disease_confidence_delta"] * 100
    risk_delta = comparison["risk_delta"]
    risk_sign = "+" if risk_delta > 0 else ""
    disease_sign = "+" if disease_delta > 0 else ""

    st.markdown(
        f"""
        <div class="compare-panel">
            <div class="compare-title">전후 비교: {escape(str(comparison["trend"]))}</div>
            <p class="compare-message">{escape(comparison["summary"])}</p>
            <div class="meta-line">
                질병 신뢰도 변화: {disease_sign}{disease_delta:.1f}%p ·
                위험도 변화: {risk_sign}{risk_delta}점
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    c1, c2 = st.columns(2)
    with c1:
        st.image(previous["image_path"], caption=f"이전 기록 · {previous['created_at']}", use_column_width=True)
        st.caption(
            f"{previous['disease_label']} · {_format_confidence(float(previous['disease_confidence']))} · "
            f"위험도 {previous['risk_score']}/100"
        )
    with c2:
        st.image(current_record["image_path"], caption=f"현재 기록 · {current_record['created_at']}", use_column_width=True)
        st.caption(
            f"{current_record['disease_label']} · {_format_confidence(float(current_record['disease_confidence']))} · "
            f"위험도 {current_record['risk_score']}/100"
        )


def _render_recent_history(plant_key: str) -> None:
    records = records_for_plant(plant_key)[-5:]
    if len(records) < 2:
        return

    with st.expander("최근 기록"):
        for record in reversed(records):
            st.write(
                f"- {record['created_at']} · {record['disease_label']} "
                f"({_format_confidence(float(record['disease_confidence']))}) · "
                f"위험도 {record['risk_score']}/100"
            )


def main() -> None:
    _inject_style()
    config_path = "configs/inference.yaml"

    _render_header()

    pipeline_error = _check_model_files(config_path)
    pipeline = None
    if pipeline_error:
        st.warning(pipeline_error)
        st.info("모델 파일을 확인한 뒤 앱을 다시 실행하세요.")
    else:
        try:
            config_mtime = Path(config_path).stat().st_mtime
            pipeline_mtime = Path("src/inference/pipeline.py").stat().st_mtime
            pipeline = load_pipeline(config_path, config_mtime, pipeline_mtime)
            if not hasattr(pipeline, "localize_disease"):
                st.cache_resource.clear()
                pipeline = load_pipeline(config_path, config_mtime, pipeline_mtime)
        except Exception as e:
            st.error(f"Pipeline load failed: {e}")
            return

    st.markdown('<div class="section-label">이미지 업로드</div>', unsafe_allow_html=True)
    plant_name_input = st.text_input("관리 대상 이름", placeholder="예: 딸기 1번 베드")
    uploaded_file = st.file_uploader("작물 이미지를 업로드하세요", type=["jpg", "jpeg", "png"], label_visibility="collapsed")

    if not uploaded_file:
        st.markdown(
            """
            <div class="upload-guide">
                작물 잎이나 열매가 잘 보이는 JPG, JPEG, PNG 이미지를 업로드하세요.
                분석 결과는 업로드 후 버튼을 누르면 바로 표시됩니다.
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="업로드 이미지", use_column_width=True)

    run = st.button("분석하기", type="primary")
    if not run:
        return

    if pipeline is None:
        st.error("Model files are missing. Please train models first.")
        return

    weather = _default_weather()

    with st.spinner("모델이 이미지를 분석하는 중입니다..."):
        result = pipeline.analyze(image)
        disease_category = _disease_category(str(result["disease"].get("label", "")))
        if disease_category != "healthy" and hasattr(pipeline, "localize_disease"):
            heatmap, heatmap_message = pipeline.localize_disease(image)
        elif disease_category == "healthy":
            heatmap = None
            heatmap_message = "정상으로 예측되어 의심 영역 시각화를 표시하지 않습니다."
        else:
            heatmap = None
            heatmap_message = "앱 캐시에 이전 파이프라인 객체가 남아 있습니다. 앱을 재시작하면 시각화를 다시 시도할 수 있습니다."

    risk = calculate_risk(
        species_result=result["species"],
        disease_result=result["disease"],
        weather=weather,
    )

    with st.spinner("관리 피드백을 생성하는 중입니다..."):
        rec = generate_recommendation(
            species_result=result["species"],
            disease_result=result["disease"],
            weather=weather,
        )

    display_name = plant_name_input.strip()
    history_enabled = bool(display_name)
    plant_key = None
    current_record = None
    comparison = None
    if history_enabled:
        plant_key = build_plant_key(display_name, str(result["species"]["label"]))
        previous_record = latest_record_for_plant(plant_key)
        current_record = save_analysis_record(
            image=image,
            plant_key=plant_key,
            display_name=display_name,
            result=result,
            risk=risk,
            recommendation=rec,
        )
        comparison = compare_records(previous_record, current_record)

    st.subheader("분석 결과")
    _render_result_cards(result)
    _render_risk_panel(risk)

    _show_top_predictions("작물 Top-3 예측", result["species"])
    _show_top_predictions("질병 Top-3 예측", result["disease"])

    if disease_category != "healthy":
        st.markdown('<div class="section-label">질병 위치 시각화</div>', unsafe_allow_html=True)
        if heatmap is not None:
            st.image(heatmap, caption="Grad-CAM 기반 의심 영역 표시", use_column_width=True)
            st.caption("빨간 경계선은 질병 분류 모델이 판단에 강하게 참고한 영역입니다. 실제 병반 확정 위치가 아니라 모델 근거 영역으로 해석하세요.")
        else:
            st.warning(f"질병 위치 시각화를 생성하지 못했습니다. {heatmap_message}")

    if history_enabled and comparison is not None and current_record is not None and plant_key is not None:
        _render_history_comparison(comparison, current_record)
        _render_recent_history(plant_key)

    _render_list_panel("진단", rec["diagnosis"])
    _render_list_panel("관리 추천", rec["actions"])

    if rec.get("recommendation_source") == "ai":
        st.caption("관리 추천은 AI가 이번 분석 결과를 바탕으로 새로 생성했습니다.")
    elif rec.get("recommendation_source") == "rules_fallback":
        st.caption("AI 추천 생성에 실패해 기본 규칙 기반 추천을 표시했습니다.")


if __name__ == "__main__":
    main()
