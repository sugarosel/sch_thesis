# PlantAI 실행 안내

이 프로젝트는 시설 작물 이미지를 업로드하면 작물 분류, 질병/정상 분류, 위험도, 관리 추천, 질병 위치 시각화, 이름 기반 히스토리 비교를 보여주는 Streamlit 앱입니다.

## 포함된 주요 기능

- 시설 작물 분류
- 질병 및 정상 분류
- 위험도 예측
- 관리 추천 생성
- 질병 위치 시각화
- 관리 대상 이름을 입력했을 때만 히스토리 저장 및 전후 비교

## 실행 방법

PowerShell에서 프로젝트 폴더로 이동한 뒤 실행합니다.

```powershell
cd "C:\Users\tony_\plant ai"
pip install -r requirements.txt
python -m streamlit run app\streamlit_app.py
```

Anaconda Python을 직접 사용할 경우:

```powershell
cd "C:\Users\tony_\plant ai"
& "C:\Users\tony_\anaconda3\python.exe" -m streamlit run app\streamlit_app.py
```

실행 후 브라우저에서 아래 주소를 엽니다.

```text
http://localhost:8501
```

## 참고

- `OPENAI_API_KEY`가 설정되어 있으면 관리 추천이 AI로 새롭게 생성됩니다.
- API 키가 없거나 호출에 실패하면 미리 준비된 규칙 기반 추천 문장을 조합해서 표시합니다.
- 히스토리 기능은 관리 대상 이름을 입력했을 때만 작동합니다.
- 앱 실행에는 `models/facility_crop_fast`와 `models/facility_disease_fast` 모델 파일이 필요합니다.
