# Training Runbook

## Recommended first run

Start with the facility disease model because it is the model used for diagnosis and
uses the external drive zip dataset.

```powershell
.\scripts\run_full_training.bat -Target disease
```

## Full training

This runs PlantNet-300K species training, facility disease training, and val/test
evaluation for both models.

```powershell
.\scripts\run_full_training.bat -Target all
```

## Species only

```powershell
.\scripts\run_full_training.bat -Target species
```

## Reuse existing manifest

Use this if `data/processed/facility_disease/manifest.csv` already exists and the
external-drive dataset did not move.

```powershell
.\scripts\run_full_training.bat -Target disease -SkipManifest
```

## Resume interrupted training

Training can resume from the previous epoch checkpoint saved as `last.pt`.

```powershell
.\scripts\run_full_training.bat -Target disease -SkipManifest -Resume
```

Species resume:

```powershell
.\scripts\run_full_training.bat -Target species -Resume
```

## Outputs

- Logs: `logs/training_*.log`
- Species checkpoint: `models/species/best.pt`
- Facility disease checkpoint: `models/facility_disease/best.pt`
- Species reports: `reports/species_val`, `reports/species_test`
- Facility disease reports: `reports/facility_disease_val`, `reports/facility_disease_test`
