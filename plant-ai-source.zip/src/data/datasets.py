import io
import zlib
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from PIL import Image, UnidentifiedImageError
from torch.utils.data import Dataset
from torchvision.datasets import ImageFolder


class CsvImageDataset(Dataset):
    def __init__(
        self,
        csv_path: str,
        image_root: str,
        split: str,
        transform=None,
        path_col: str = "image_path",
        label_col: str = "label",
        split_col: str = "split",
        class_to_idx: Optional[Dict[str, int]] = None,
    ) -> None:
        self.df = pd.read_csv(csv_path)
        if split_col in self.df.columns:
            self.df = self.df[self.df[split_col] == split].reset_index(drop=True)

        self.image_root = Path(image_root)
        self.transform = transform
        self.path_col = path_col
        self.label_col = label_col

        if class_to_idx is None:
            classes = sorted(self.df[label_col].astype(str).unique().tolist())
            self.class_to_idx = {name: idx for idx, name in enumerate(classes)}
        else:
            self.class_to_idx = class_to_idx

        self.targets: List[int] = [self.class_to_idx[str(v)] for v in self.df[label_col].tolist()]

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        image_path = self.image_root / str(row[self.path_col])
        image = Image.open(image_path).convert("RGB")
        target = self.class_to_idx[str(row[self.label_col])]

        if self.transform is not None:
            image = self.transform(image)
        return image, target


class ZipCsvImageDataset(Dataset):
    def __init__(
        self,
        csv_path: str,
        split: str,
        transform=None,
        image_zip_col: str = "image_zip",
        image_member_col: str = "image_member",
        label_col: str = "label",
        split_col: str = "split",
        class_to_idx: Optional[Dict[str, int]] = None,
    ) -> None:
        self.df = pd.read_csv(csv_path)
        if split_col in self.df.columns:
            self.df = self.df[self.df[split_col] == split].reset_index(drop=True)

        self.transform = transform
        self.image_zip_col = image_zip_col
        self.image_member_col = image_member_col
        self.label_col = label_col
        self._warned_bad_indices = set()
        self._bad_indices = set()
        self._warned_placeholder = False

        if class_to_idx is None:
            classes = sorted(self.df[label_col].astype(str).unique().tolist())
            self.class_to_idx = {name: idx for idx, name in enumerate(classes)}
        else:
            self.class_to_idx = class_to_idx

        self.targets: List[int] = [self.class_to_idx[str(v)] for v in self.df[label_col].tolist()]
        self._indices_by_target: Dict[int, List[int]] = {}
        for row_idx, target in enumerate(self.targets):
            self._indices_by_target.setdefault(target, []).append(row_idx)

    def __getstate__(self):
        state = self.__dict__.copy()
        return state

    def __len__(self) -> int:
        return len(self.df)

    def _replacement_indices(self, idx: int, max_attempts: int) -> List[int]:
        target = self.targets[idx]
        pool = self._indices_by_target.get(target, [])
        candidates = [idx]
        if len(pool) <= 1:
            return candidates

        same_label_attempts = max(1, max_attempts // 2)
        for attempt in range(1, same_label_attempts):
            # Jump around within the same label to avoid a local block of corrupt zip entries.
            pool_pos = (idx * 9973 + attempt * 7919) % len(pool)
            candidates.append(pool[pool_pos])

        for attempt in range(same_label_attempts, max_attempts):
            # Last-resort global fallback. This keeps long training runs alive even when
            # a rare class has several corrupt zip members.
            candidates.append((idx * 104729 + attempt * 1299709) % len(self.df))
        return candidates

    def _read_item(self, idx: int):
        row = self.df.iloc[idx]
        zip_path = str(row[self.image_zip_col])
        image_member = str(row[self.image_member_col])

        with zipfile.ZipFile(zip_path) as zf:
            with zf.open(image_member) as f:
                image_bytes = f.read()
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        target = self.class_to_idx[str(row[self.label_col])]

        if self.transform is not None:
            image = self.transform(image)
        return image, target

    def __getitem__(self, idx: int):
        max_attempts = min(100, len(self.df))
        last_error = None

        for candidate_idx in self._replacement_indices(idx, max_attempts):
            if candidate_idx in self._bad_indices:
                continue
            try:
                return self._read_item(candidate_idx)
            except (
                zlib.error,
                zipfile.BadZipFile,
                KeyError,
                OSError,
                UnidentifiedImageError,
            ) as exc:
                last_error = exc
                self._bad_indices.add(candidate_idx)
                row = self.df.iloc[candidate_idx]
                if candidate_idx not in self._warned_bad_indices and len(self._warned_bad_indices) < 20:
                    print(
                        "[WARN] Skipping unreadable zip image: "
                        f"idx={candidate_idx}, zip={row[self.image_zip_col]}, "
                        f"member={row[self.image_member_col]}, error={exc}"
                    )
                    self._warned_bad_indices.add(candidate_idx)

        if not self._warned_placeholder:
            print(
                "[WARN] Could not find a readable replacement after "
                f"{max_attempts} attempts. Using a blank placeholder image. "
                f"Last error={last_error}"
            )
            self._warned_placeholder = True

        image = Image.new("RGB", (224, 224), color=(0, 0, 0))
        target = self.targets[idx]
        if self.transform is not None:
            image = self.transform(image)
        return image, target


def _build_csv_class_map(data_cfg: Dict) -> Dict[str, int]:
    csv_path = data_cfg["csv_path"]
    label_col = data_cfg.get("label_col", "label")
    df = pd.read_csv(csv_path)
    classes = sorted(df[label_col].astype(str).unique().tolist())
    return {name: idx for idx, name in enumerate(classes)}


def _build_split_filtered_class_map(data_cfg: Dict) -> Dict[str, int]:
    csv_path = data_cfg["csv_path"]
    label_col = data_cfg.get("label_col", "label")
    split_col = data_cfg.get("split_col", "split")
    df = pd.read_csv(csv_path)
    if split_col in df.columns:
        df = df[df[split_col].isin(["train", "val", "test"])]
    classes = sorted(df[label_col].astype(str).unique().tolist())
    return {name: idx for idx, name in enumerate(classes)}


def build_class_map(data_cfg: Dict) -> Dict[str, int]:
    data_format = data_cfg.get("format", "imagefolder").lower()

    if data_format == "imagefolder":
        return ImageFolder(root=data_cfg["train_dir"]).class_to_idx

    if data_format == "csv":
        return _build_csv_class_map(data_cfg)

    if data_format == "zip_csv":
        return _build_split_filtered_class_map(data_cfg)

    raise ValueError(f"Unsupported data.format: {data_format}")


def build_dataset(data_cfg: Dict, split: str, transform, class_to_idx: Optional[Dict[str, int]] = None):
    data_format = data_cfg.get("format", "imagefolder").lower()
    class_to_idx = class_to_idx or build_class_map(data_cfg)

    if data_format == "imagefolder":
        split_dir_key = f"{split}_dir"
        if split_dir_key not in data_cfg:
            raise KeyError(f"Missing data.{split_dir_key} for imagefolder split '{split}'")
        dataset = ImageFolder(root=data_cfg[split_dir_key], transform=transform)
        if dataset.class_to_idx != class_to_idx:
            raise ValueError(
                f"Class map mismatch for split '{split}'. "
                "Make sure train/val/test folders contain the same class directory names."
            )
        return _maybe_limit_dataset(dataset, data_cfg, split)

    if data_format == "csv":
        dataset = CsvImageDataset(
            csv_path=data_cfg["csv_path"],
            image_root=data_cfg["image_root"],
            split=split,
            transform=transform,
            path_col=data_cfg.get("path_col", "image_path"),
            label_col=data_cfg.get("label_col", "label"),
            split_col=data_cfg.get("split_col", "split"),
            class_to_idx=class_to_idx,
        )
        return _maybe_limit_dataset(dataset, data_cfg, split)

    if data_format == "zip_csv":
        dataset = ZipCsvImageDataset(
            csv_path=data_cfg["csv_path"],
            split=split,
            transform=transform,
            image_zip_col=data_cfg.get("image_zip_col", "image_zip"),
            image_member_col=data_cfg.get("image_member_col", "image_member"),
            label_col=data_cfg.get("label_col", "label"),
            split_col=data_cfg.get("split_col", "split"),
            class_to_idx=class_to_idx,
        )
        return _maybe_limit_dataset(dataset, data_cfg, split)

    raise ValueError(f"Unsupported data.format: {data_format}")


def _maybe_limit_dataset(dataset, data_cfg: Dict, split: str):
    limit_key = f"{split}_limit"
    limit = int(data_cfg.get(limit_key, data_cfg.get("limit", 0)) or 0)
    if limit <= 0 or limit >= len(dataset):
        return dataset

    from torch.utils.data import Subset

    indices_by_target: Dict[int, List[int]] = {}
    for idx, target in enumerate(dataset.targets):
        indices_by_target.setdefault(int(target), []).append(idx)

    indices = []
    class_ids = sorted(indices_by_target)
    cursor = 0
    while len(indices) < limit and class_ids:
        target = class_ids[cursor % len(class_ids)]
        class_indices = indices_by_target[target]
        if class_indices:
            indices.append(class_indices.pop(0))
        else:
            class_ids.remove(target)
            cursor -= 1
        cursor += 1

    subset = Subset(dataset, indices)
    subset.targets = [dataset.targets[i] for i in indices]
    if hasattr(dataset, "class_to_idx"):
        subset.class_to_idx = dataset.class_to_idx
    return subset


def build_datasets(data_cfg: Dict, train_transform, eval_transform):
    class_to_idx = build_class_map(data_cfg)
    train_ds = build_dataset(data_cfg, "train", train_transform, class_to_idx=class_to_idx)
    val_ds = build_dataset(data_cfg, "val", eval_transform, class_to_idx=class_to_idx)
    return train_ds, val_ds, class_to_idx
