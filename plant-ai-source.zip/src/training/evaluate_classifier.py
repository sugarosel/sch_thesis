import argparse
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.data.datasets import build_class_map, build_dataset
from src.data.transforms import build_eval_transform
from src.models.backbones import build_classifier
from src.utils.config import deep_get, load_config
from src.utils.io import save_json


@torch.no_grad()
def _predict(model, loader: DataLoader, device: torch.device):
    model.eval()
    y_true: List[int] = []
    y_pred: List[int] = []

    for images, labels in tqdm(loader, desc="[Eval]", leave=False):
        images = images.to(device)
        labels = labels.to(device)
        logits = model(images)
        preds = logits.argmax(dim=1)
        y_true.extend(labels.cpu().numpy().tolist())
        y_pred.extend(preds.cpu().numpy().tolist())
    return np.array(y_true), np.array(y_pred)


def run_evaluation(config_path: str, checkpoint_path: str, output_dir: str, split: str = "val") -> None:
    cfg = load_config(config_path)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    image_size = int(deep_get(cfg, "data.image_size", 224))
    eval_tf = build_eval_transform(image_size=image_size)
    class_to_idx = build_class_map(cfg["data"])
    eval_ds = build_dataset(cfg["data"], split, eval_tf, class_to_idx=class_to_idx)

    eval_loader = DataLoader(
        eval_ds,
        batch_size=int(deep_get(cfg, "train.batch_size", 32)),
        shuffle=False,
        num_workers=int(deep_get(cfg, "train.num_workers", 2)),
        pin_memory=device.type == "cuda",
    )

    idx_to_class: Dict[int, str] = {v: k for k, v in class_to_idx.items()}
    num_classes = len(class_to_idx)

    model = build_classifier(
        backbone=deep_get(cfg, "model.backbone", "efficientnet_b0"),
        num_classes=num_classes,
        pretrained=False,
        dropout=float(deep_get(cfg, "model.dropout", 0.2)),
    )
    ckpt = torch.load(checkpoint_path, map_location=device)
    state_dict = ckpt.get("model_state_dict", ckpt)
    model.load_state_dict(state_dict)
    model.to(device)

    y_true, y_pred = _predict(model, eval_loader, device)

    acc = float(accuracy_score(y_true, y_pred))
    macro_f1 = float(f1_score(y_true, y_pred, average="macro", zero_division=0))
    weighted_f1 = float(f1_score(y_true, y_pred, average="weighted", zero_division=0))

    labels = list(range(num_classes))
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    class_names = [idx_to_class[i] for i in labels]
    cm_df = pd.DataFrame(cm, index=class_names, columns=class_names)

    report = classification_report(
        y_true,
        y_pred,
        labels=labels,
        target_names=class_names,
        zero_division=0,
        output_dict=True,
    )

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    metrics = {
        "accuracy": acc,
        "macro_f1": macro_f1,
        "weighted_f1": weighted_f1,
        "num_classes": num_classes,
        "num_samples": int(len(y_true)),
        "split": split,
    }
    save_json(metrics, str(out / "metrics.json"))
    save_json(report, str(out / "classification_report.json"))
    cm_df.to_csv(out / "confusion_matrix.csv", encoding="utf-8")

    mis_rows = []
    for t, p in zip(y_true.tolist(), y_pred.tolist()):
        if t != p:
            mis_rows.append({"true": idx_to_class[t], "pred": idx_to_class[p]})
    if mis_rows:
        mis_df = pd.DataFrame(mis_rows)
        top_mis = (
            mis_df.value_counts(["true", "pred"])
            .reset_index(name="count")
            .sort_values("count", ascending=False)
        )
        top_mis.to_csv(out / "top_misclassifications.csv", index=False, encoding="utf-8")
    else:
        pd.DataFrame(columns=["true", "pred", "count"]).to_csv(
            out / "top_misclassifications.csv", index=False, encoding="utf-8"
        )

    print(f"[Eval:{split}] accuracy={acc:.4f}, macro_f1={macro_f1:.4f}, weighted_f1={weighted_f1:.4f}")
    print(f"[Eval] reports saved to: {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--output_dir", type=str, default="reports/eval")
    parser.add_argument("--split", type=str, default="val", choices=["val", "test"])
    args = parser.parse_args()

    run_evaluation(args.config, args.checkpoint, args.output_dir, split=args.split)
