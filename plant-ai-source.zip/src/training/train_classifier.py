import argparse
from pathlib import Path
from typing import Dict

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader, WeightedRandomSampler

from src.data.datasets import build_datasets
from src.data.transforms import get_transforms
from src.models.backbones import build_classifier
from src.models.losses import build_loss
from src.training.engine import evaluate, train_one_epoch
from src.utils.config import deep_get, load_config
from src.utils.io import save_json
from src.utils.seed import set_seed


def _compute_class_weights(targets, num_classes: int) -> torch.Tensor:
    counts = torch.zeros(num_classes, dtype=torch.float32)
    for t in targets:
        counts[int(t)] += 1
    counts = torch.clamp(counts, min=1.0)
    weights = counts.sum() / (num_classes * counts)
    return weights


def _build_weighted_sampler(targets, num_classes: int) -> WeightedRandomSampler:
    counts = torch.zeros(num_classes, dtype=torch.float32)
    for t in targets:
        counts[int(t)] += 1
    counts = torch.clamp(counts, min=1.0)
    class_weights = 1.0 / counts
    sample_weights = torch.tensor([float(class_weights[int(t)].item()) for t in targets], dtype=torch.double)
    return WeightedRandomSampler(weights=sample_weights, num_samples=len(sample_weights), replacement=True)


def run_training(config_path: str, resume_path: str = "") -> None:
    cfg = load_config(config_path)
    set_seed(int(deep_get(cfg, "train.seed", 42)))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    image_size = int(deep_get(cfg, "data.image_size", 224))
    train_tf, eval_tf = get_transforms(image_size=image_size)

    train_ds, val_ds, class_to_idx = build_datasets(cfg["data"], train_tf, eval_tf)
    cfg_num_classes = int(deep_get(cfg, "model.num_classes", len(class_to_idx)))
    num_classes = len(class_to_idx)
    if cfg_num_classes != num_classes:
        print(
            f"[WARN] model.num_classes={cfg_num_classes} but dataset has {num_classes} classes. "
            "Using dataset class count."
        )

    batch_size = int(deep_get(cfg, "train.batch_size", 32))
    num_workers = int(deep_get(cfg, "train.num_workers", 2))
    use_pin_memory = device.type == "cuda"

    use_weighted_sampler = bool(deep_get(cfg, "train.weighted_sampler", False))
    sampler = _build_weighted_sampler(train_ds.targets, num_classes) if use_weighted_sampler else None

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=(sampler is None),
        sampler=sampler,
        num_workers=num_workers,
        pin_memory=use_pin_memory,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=use_pin_memory,
    )

    model = build_classifier(
        backbone=deep_get(cfg, "model.backbone", "efficientnet_b0"),
        num_classes=num_classes,
        pretrained=bool(deep_get(cfg, "model.pretrained", True)),
        dropout=float(deep_get(cfg, "model.dropout", 0.2)),
    ).to(device)

    weighted = bool(deep_get(cfg, "train.weighted_loss", False))
    class_weights = None
    if weighted:
        class_weights = _compute_class_weights(train_ds.targets, num_classes).to(device)

    criterion = build_loss(
        loss_type=deep_get(cfg, "train.loss_type", "cross_entropy"),
        class_weights=class_weights,
        focal_gamma=float(deep_get(cfg, "train.focal_gamma", 2.0)),
    )

    optimizer = AdamW(
        model.parameters(),
        lr=float(deep_get(cfg, "train.lr", 1e-3)),
        weight_decay=float(deep_get(cfg, "train.weight_decay", 1e-4)),
    )

    epochs = int(deep_get(cfg, "train.epochs", 10))
    save_dir = Path(deep_get(cfg, "train.save_dir", "models/tmp"))
    save_dir.mkdir(parents=True, exist_ok=True)

    best_acc = 0.0
    start_epoch = 1
    idx_to_class = {v: k for k, v in class_to_idx.items()}

    if resume_path:
        resume = Path(resume_path)
        if not resume.exists():
            raise FileNotFoundError(f"Resume checkpoint not found: {resume}")

        ckpt = torch.load(resume, map_location=device)
        checkpoint_class_to_idx = ckpt.get("class_to_idx")
        if checkpoint_class_to_idx and checkpoint_class_to_idx != class_to_idx:
            raise ValueError("Resume checkpoint class_to_idx does not match the current dataset.")

        model.load_state_dict(ckpt["model_state_dict"])
        if "optimizer_state_dict" in ckpt:
            optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        else:
            print("[WARN] Resume checkpoint has no optimizer_state_dict. Optimizer was reinitialized.")

        start_epoch = int(ckpt.get("epoch", 0)) + 1
        best_acc = float(ckpt.get("best_acc", ckpt.get("val_acc", 0.0)))
        print(f"Resuming from {resume} at epoch {start_epoch}/{epochs}. best_acc={best_acc:.4f}")

    if start_epoch > epochs:
        print(f"Checkpoint already reached epoch {start_epoch - 1}; target epochs={epochs}. Nothing to train.")

    for epoch in range(start_epoch, epochs + 1):
        train_metrics = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_metrics = evaluate(model, val_loader, criterion, device)

        print(
            f"Epoch {epoch}/{epochs} | "
            f"train_loss={train_metrics['loss']:.4f}, train_acc={train_metrics['acc']:.4f} | "
            f"val_loss={val_metrics['loss']:.4f}, val_acc={val_metrics['acc']:.4f}"
        )

        payload: Dict = {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "class_to_idx": class_to_idx,
            "config": cfg,
            "val_acc": val_metrics["acc"],
            "best_acc": best_acc,
        }

        torch.save(payload, save_dir / "last.pt")

        if val_metrics["acc"] > best_acc:
            best_acc = val_metrics["acc"]
            payload["best_acc"] = best_acc
            torch.save(payload, save_dir / "best.pt")

    save_json(class_to_idx, str(save_dir / "class_to_idx.json"))
    save_json({str(k): v for k, v in idx_to_class.items()}, str(save_dir / "idx_to_class.json"))
    print(f"Training finished. Best val_acc={best_acc:.4f}. Saved to {save_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--resume", type=str, default="")
    args = parser.parse_args()
    run_training(args.config, resume_path=args.resume)
