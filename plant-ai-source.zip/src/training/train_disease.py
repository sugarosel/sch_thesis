import argparse

from src.training.train_classifier import run_training


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/disease_train.yaml")
    parser.add_argument("--resume", type=str, default="")
    args = parser.parse_args()
    run_training(args.config, resume_path=args.resume)
