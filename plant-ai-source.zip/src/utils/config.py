from pathlib import Path
from typing import Any, Dict

import yaml


def load_config(config_path: str) -> Dict[str, Any]:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def deep_get(data: Dict[str, Any], keys: str, default: Any = None) -> Any:
    current: Any = data
    for key in keys.split("."):
        if not isinstance(current, dict) or key not in current:
            return default
        current = current[key]
    return current
