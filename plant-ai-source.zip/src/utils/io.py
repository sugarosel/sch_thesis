import json
from pathlib import Path
from typing import Dict


def save_json(data: Dict, path: str) -> None:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_json(path: str) -> Dict:
    with Path(path).open("r", encoding="utf-8") as f:
        return json.load(f)
