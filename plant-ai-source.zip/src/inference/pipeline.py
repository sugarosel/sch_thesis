from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from PIL import Image, ImageDraw

from src.data.transforms import build_eval_transform
from src.models.backbones import build_classifier
from src.utils.config import load_config
from src.utils.io import load_json


class SingleClassifier:
    def __init__(
        self,
        checkpoint_path: str,
        class_map_path: Optional[str],
        backbone: str,
        image_size: int = 224,
        device: str = "cpu",
        label_map: Optional[Dict[str, str]] = None,
    ) -> None:
        self.device = torch.device(device)
        ckpt = torch.load(checkpoint_path, map_location=self.device)
        if class_map_path and Path(class_map_path).exists():
            class_to_idx = load_json(class_map_path)
        else:
            class_to_idx = ckpt.get("class_to_idx")
        if not class_to_idx:
            raise FileNotFoundError(
                f"Class map not found. Provide class_map_path or use a checkpoint with class_to_idx: {checkpoint_path}"
            )
        self.idx_to_class = {int(v): k for k, v in class_to_idx.items()}
        self.label_map = label_map or {}
        self.backbone = backbone.lower()
        num_classes = len(self.idx_to_class)

        self.model = build_classifier(
            backbone=backbone,
            num_classes=num_classes,
            pretrained=False,
        )

        state_dict = ckpt.get("model_state_dict", ckpt)
        self.model.load_state_dict(state_dict)
        self.model.to(self.device)
        self.model.eval()

        self.transform = build_eval_transform(image_size=image_size)

    def _target_layer(self):
        if self.backbone == "efficientnet_b0" and hasattr(self.model, "features"):
            return self.model.features[-1]
        if self.backbone == "resnet18" and hasattr(self.model, "layer4"):
            return self.model.layer4
        return None

    def _display_label(self, raw_label: str) -> str:
        return self.label_map.get(raw_label, raw_label)

    @torch.no_grad()
    def predict(self, image: Image.Image, top_k: int = 3) -> Dict:
        x = self.transform(image).unsqueeze(0).to(self.device)
        logits = self.model(x)
        probs = torch.softmax(logits, dim=1)
        conf, pred = torch.max(probs, dim=1)

        top_prob, top_idx = torch.topk(probs, k=min(top_k, probs.shape[1]), dim=1)
        top_predictions: List[Dict] = []
        for p, i in zip(top_prob[0].tolist(), top_idx[0].tolist()):
            raw_label = self.idx_to_class[int(i)]
            top_predictions.append(
                {
                    "raw_label": raw_label,
                    "label": self._display_label(raw_label),
                    "confidence": float(p),
                }
            )

        raw_pred = self.idx_to_class[int(pred.item())]
        return {
            "raw_label": raw_pred,
            "label": self._display_label(raw_pred),
            "confidence": float(conf.item()),
            "top_k": top_predictions,
        }

    def gradcam_overlay(self, image: Image.Image, alpha: float = 0.48) -> Tuple[Optional[Image.Image], str]:
        target_layer = self._target_layer()
        if target_layer is None:
            return None, f"{self.backbone} 백본은 Grad-CAM 대상 레이어를 찾지 못했습니다."

        activations = []
        gradients = []

        def forward_hook(_module, _inputs, output):
            activations.append(output.detach())

        def backward_hook(_module, _grad_input, grad_output):
            gradients.append(grad_output[0].detach())

        forward_handle = target_layer.register_forward_hook(forward_hook)
        backward_handle = target_layer.register_full_backward_hook(backward_hook)

        try:
            x = self.transform(image).unsqueeze(0).to(self.device)
            self.model.zero_grad(set_to_none=True)
            logits = self.model(x)
            pred_idx = int(torch.argmax(logits, dim=1).item())
            logits[0, pred_idx].backward()

            if not activations or not gradients:
                return None, "Grad-CAM hook에서 feature map 또는 gradient를 얻지 못했습니다."

            activation = activations[-1]
            gradient = gradients[-1]
            weights = gradient.mean(dim=(2, 3), keepdim=True)
            raw_cam = (weights * activation).sum(dim=1).squeeze(0)
            cam = torch.relu(raw_cam)

            if float(torch.max(cam).item()) <= 0:
                cam = raw_cam - torch.min(raw_cam)

            max_value = torch.max(cam)
            min_value = torch.min(cam)
            if float((max_value - min_value).item()) <= 1e-8:
                cam = torch.abs(raw_cam)
                max_value = torch.max(cam)
                if float(max_value.item()) <= 1e-8:
                    return None, "Grad-CAM 값이 거의 0이라 시각화할 영역을 만들지 못했습니다."
                cam = cam / max_value
            else:
                cam = (cam - min_value) / (max_value - min_value)

            heatmap = cam.cpu().numpy()
            return _mark_heatmap_regions(image, heatmap, alpha=alpha), "ok"
        finally:
            forward_handle.remove()
            backward_handle.remove()


class PlantDiagnosisPipeline:
    def __init__(self, config_path: str = "configs/inference.yaml") -> None:
        cfg = load_config(config_path)

        device = cfg.get("device", "cpu")
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"

        self.species_model = SingleClassifier(
            checkpoint_path=cfg["species"]["checkpoint_path"],
            class_map_path=cfg["species"]["class_map_path"],
            backbone=cfg["species"].get("backbone", "efficientnet_b0"),
            image_size=int(cfg["species"].get("image_size", 224)),
            device=device,
            label_map=cfg["species"].get("label_map", {}),
        )
        self.disease_model = SingleClassifier(
            checkpoint_path=cfg["disease"]["checkpoint_path"],
            class_map_path=cfg["disease"]["class_map_path"],
            backbone=cfg["disease"].get("backbone", "efficientnet_b0"),
            image_size=int(cfg["disease"].get("image_size", 224)),
            device=device,
            label_map=cfg["disease"].get("label_map", {}),
        )

    def analyze(self, image: Image.Image) -> Dict:
        if image.mode != "RGB":
            image = image.convert("RGB")

        species_result = self.species_model.predict(image)
        disease_result = self.disease_model.predict(image)

        return {
            "species": species_result,
            "disease": disease_result,
        }

    def localize_disease(self, image: Image.Image) -> Tuple[Optional[Image.Image], str]:
        if image.mode != "RGB":
            image = image.convert("RGB")
        return self.disease_model.gradcam_overlay(image)


def _overlay_heatmap(image: Image.Image, heatmap: np.ndarray, alpha: float = 0.42) -> Image.Image:
    base = image.convert("RGB")
    heatmap_image = Image.fromarray((heatmap * 255).astype(np.uint8)).resize(base.size, Image.Resampling.BILINEAR)
    heatmap_arr = np.asarray(heatmap_image).astype(np.float32) / 255.0

    color_arr = np.zeros((heatmap_arr.shape[0], heatmap_arr.shape[1], 3), dtype=np.uint8)
    color_arr[..., 0] = np.clip(heatmap_arr * 255, 0, 255).astype(np.uint8)
    color_arr[..., 1] = np.clip(np.power(heatmap_arr, 0.7) * 185, 0, 185).astype(np.uint8)

    color = Image.fromarray(color_arr, mode="RGB")
    return Image.blend(base, color, alpha=alpha)


def _mark_heatmap_regions(image: Image.Image, heatmap: np.ndarray, alpha: float = 0.18) -> Image.Image:
    base = image.convert("RGB")
    heatmap_image = Image.fromarray((heatmap * 255).astype(np.uint8)).resize(base.size, Image.Resampling.BILINEAR)
    heatmap_arr = np.asarray(heatmap_image).astype(np.float32) / 255.0

    threshold = max(0.55, float(np.quantile(heatmap_arr, 0.88)))
    mask = heatmap_arr >= threshold
    if int(mask.sum()) < 12:
        threshold = max(0.40, float(np.quantile(heatmap_arr, 0.80)))
        mask = heatmap_arr >= threshold

    marked = _overlay_heatmap(base, heatmap, alpha=alpha)
    draw = ImageDraw.Draw(marked)

    boxes = _connected_component_boxes(mask, min_area=max(20, int(mask.size * 0.002)))
    if not boxes:
        y_idx, x_idx = np.where(mask)
        if len(x_idx) == 0:
            return marked
        boxes = [(int(x_idx.min()), int(y_idx.min()), int(x_idx.max()), int(y_idx.max()))]

    width, height = base.size
    line_width = max(3, min(width, height) // 110)
    for box in boxes[:3]:
        x1, y1, x2, y2 = _pad_box(box, width, height)
        draw.rounded_rectangle((x1, y1, x2, y2), radius=12, outline=(255, 45, 45), width=line_width)
        draw.ellipse((x1 - 5, y1 - 5, x1 + 5, y1 + 5), fill=(255, 45, 45))

    return marked


def _connected_component_boxes(mask: np.ndarray, min_area: int) -> List[Tuple[int, int, int, int]]:
    height, width = mask.shape
    visited = np.zeros_like(mask, dtype=bool)
    boxes = []

    for start_y in range(height):
        for start_x in range(width):
            if not mask[start_y, start_x] or visited[start_y, start_x]:
                continue

            stack = [(start_x, start_y)]
            visited[start_y, start_x] = True
            xs = []
            ys = []

            while stack:
                x, y = stack.pop()
                xs.append(x)
                ys.append(y)

                for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if nx < 0 or ny < 0 or nx >= width or ny >= height:
                        continue
                    if visited[ny, nx] or not mask[ny, nx]:
                        continue
                    visited[ny, nx] = True
                    stack.append((nx, ny))

            if len(xs) >= min_area:
                boxes.append((min(xs), min(ys), max(xs), max(ys)))

    boxes.sort(key=lambda box: (box[2] - box[0] + 1) * (box[3] - box[1] + 1), reverse=True)
    return boxes


def _pad_box(box: Tuple[int, int, int, int], width: int, height: int) -> Tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    pad = max(8, min(width, height) // 35)
    return (
        max(0, x1 - pad),
        max(0, y1 - pad),
        min(width - 1, x2 + pad),
        min(height - 1, y2 + pad),
    )
