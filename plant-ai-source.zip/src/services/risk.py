from typing import Dict, List

from src.services.recommendation import _disease_category


def calculate_risk(species_result: Dict, disease_result: Dict, weather: Dict) -> Dict:
    disease_label = disease_result.get("label", "unknown")
    disease_confidence = float(disease_result.get("confidence", 0.0))
    category = _disease_category(disease_label)

    if category == "healthy":
        score = max(5, int((1.0 - disease_confidence) * 35))
    else:
        score = 35 + int(disease_confidence * 45)

    factors: List[str] = []
    humidity = weather.get("humidity")
    temp = weather.get("temperature_c")
    precipitation = weather.get("precipitation_mm", 0.0)
    sunlight = weather.get("sunlight_level", "medium")

    if humidity is not None and humidity >= 80:
        score += 12
        factors.append("높은 습도")
    elif humidity is not None and humidity >= 70:
        score += 6
        factors.append("다소 높은 습도")

    if temp is not None and temp >= 33:
        score += 8
        factors.append("고온 스트레스")
    elif temp is not None and temp <= 10:
        score += 6
        factors.append("저온 스트레스")

    if precipitation is not None and precipitation >= 3:
        score += 5
        factors.append("최근 강수")

    if sunlight == "low":
        score += 5
        factors.append("낮은 일조량")

    score = max(0, min(100, score))

    if score >= 70:
        level = "높음"
        message = "오늘은 격리, 통풍, 추가 관찰을 우선하는 것이 좋습니다."
    elif score >= 40:
        level = "주의"
        message = "환경을 조정하고 1-2일 안에 같은 부위를 다시 확인하세요."
    else:
        level = "낮음"
        message = "현재는 유지 관리를 중심으로 상태 변화를 기록하세요."

    if category != "healthy" and disease_confidence < 0.55:
        factors.append("낮은 예측 신뢰도")

    return {
        "score": score,
        "level": level,
        "message": message,
        "factors": factors or ["모델 예측 결과"],
        "disease_category": category,
        "plant": species_result.get("label", "unknown"),
        "disease": disease_label,
    }
