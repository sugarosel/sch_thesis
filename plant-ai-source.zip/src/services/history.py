import json
import re
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from PIL import Image


HISTORY_DIR = Path("data/app_history")
HISTORY_IMAGE_DIR = HISTORY_DIR / "images"
HISTORY_PATH = HISTORY_DIR / "analysis_history.json"


def _slugify(value: str) -> str:
    slug = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", value.strip())
    return slug.strip("_") or "plant"


def load_history() -> List[Dict]:
    if not HISTORY_PATH.exists():
        return []

    try:
        with HISTORY_PATH.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []

    if not isinstance(data, list):
        return []
    return data


def _write_history(records: List[Dict]) -> None:
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    with HISTORY_PATH.open("w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def records_for_plant(plant_key: str) -> List[Dict]:
    return [record for record in load_history() if record.get("plant_key") == plant_key]


def latest_record_for_plant(plant_key: str) -> Optional[Dict]:
    records = records_for_plant(plant_key)
    if not records:
        return None
    return records[-1]


def save_analysis_record(
    image: Image.Image,
    plant_key: str,
    display_name: str,
    result: Dict,
    risk: Dict,
    recommendation: Dict,
) -> Dict:
    HISTORY_IMAGE_DIR.mkdir(parents=True, exist_ok=True)

    record_id = uuid.uuid4().hex[:12]
    created_at = datetime.now().isoformat(timespec="seconds")
    image_name = f"{created_at.replace(':', '-')}_{record_id}.jpg"
    image_path = HISTORY_IMAGE_DIR / image_name
    image.convert("RGB").save(image_path, format="JPEG", quality=90)

    record = {
        "id": record_id,
        "created_at": created_at,
        "plant_key": plant_key,
        "display_name": display_name,
        "image_path": str(image_path),
        "species_label": result["species"].get("label", "unknown"),
        "species_confidence": float(result["species"].get("confidence", 0.0)),
        "disease_label": result["disease"].get("label", "unknown"),
        "disease_confidence": float(result["disease"].get("confidence", 0.0)),
        "risk_score": int(risk.get("score", 0)),
        "risk_level": risk.get("level", "unknown"),
        "recommendation_source": recommendation.get("recommendation_source", "unknown"),
    }

    records = load_history()
    records.append(record)
    _write_history(records)
    return record


def compare_records(previous: Optional[Dict], current: Dict) -> Dict:
    if not previous:
        return {
            "has_previous": False,
            "summary": "이 관리 대상의 첫 기록입니다. 다음 분석부터 변화 추이를 비교할 수 있습니다.",
        }

    disease_delta = float(current["disease_confidence"]) - float(previous.get("disease_confidence", 0.0))
    risk_delta = int(current["risk_score"]) - int(previous.get("risk_score", 0))

    if risk_delta <= -10:
        trend = "개선"
        summary = "이전 기록보다 위험도가 뚜렷하게 낮아졌습니다."
    elif risk_delta >= 10:
        trend = "악화"
        summary = "이전 기록보다 위험도가 올라가 추가 관찰이 필요합니다."
    else:
        trend = "유지"
        summary = "이전 기록과 비교해 위험도 변화가 크지 않습니다."

    return {
        "has_previous": True,
        "trend": trend,
        "summary": summary,
        "previous": previous,
        "disease_confidence_delta": disease_delta,
        "risk_delta": risk_delta,
    }


def build_plant_key(display_name: str, species_label: str) -> str:
    base = display_name.strip() or species_label
    return _slugify(base)
