import os
from typing import Dict, Optional

import requests
from dotenv import load_dotenv


load_dotenv()


class WeatherServiceError(Exception):
    pass


def _infer_sunlight_level(cloudiness: Optional[float], weather_main: str) -> str:
    w = (weather_main or "").lower()
    if "clear" in w:
        return "high"
    if cloudiness is None:
        return "medium"
    if cloudiness <= 30:
        return "high"
    if cloudiness <= 70:
        return "medium"
    return "low"


def fetch_openweather_by_city(city_name: str, api_key: Optional[str] = None, lang: str = "kr") -> Dict:
    key = api_key or os.getenv("OPENWEATHER_API_KEY")
    if not key:
        raise WeatherServiceError("OPENWEATHER_API_KEY가 설정되지 않았습니다.")

    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city_name,
        "appid": key,
        "units": "metric",
        "lang": lang,
    }

    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as exc:
        raise WeatherServiceError(f"날씨 API 호출 실패: {exc}") from exc

    data = resp.json()

    weather_items = data.get("weather", [{}])
    weather_main = weather_items[0].get("main", "")
    weather_desc = weather_items[0].get("description", "정보 없음")
    rain_1h = (data.get("rain") or {}).get("1h", 0.0)
    cloudiness = (data.get("clouds") or {}).get("all")

    return {
        "location": city_name,
        "temperature_c": (data.get("main") or {}).get("temp"),
        "humidity": (data.get("main") or {}).get("humidity"),
        "precipitation_mm": rain_1h,
        "weather_main": weather_main,
        "weather_description": weather_desc,
        "cloudiness": cloudiness,
        "sunlight_level": _infer_sunlight_level(cloudiness, weather_main),
    }
