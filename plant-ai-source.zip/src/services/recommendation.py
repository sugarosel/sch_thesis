import json
import os
import random
from typing import Dict, List, Optional
from urllib import error, request

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


if load_dotenv is not None:
    load_dotenv()

OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"
DEFAULT_RECOMMENDATION_MODEL = "gpt-4.1-mini"


DISEASE_CATEGORY_VALUES = ["healthy", "fungal", "bacterial", "viral", "unknown"]


def _disease_category(disease_label: str) -> str:
    label = disease_label.lower()
    if "healthy" in label or "normal" in label or "정상" in disease_label:
        return "healthy"
    fungal_keywords = [
        "blight",
        "mildew",
        "mold",
        "rust",
        "scab",
        "spot",
        "곰팡이",
        "균핵",
        "노균",
        "탄저",
        "흰가루",
        "점무늬",
        "잿빛",
    ]
    bacterial_keywords = ["bacterial", "canker", "세균", "무름"]
    viral_keywords = ["virus", "viral", "mosaic", "바이러스", "모자이크", "황화잎말이", "모틀"]

    if any(keyword in label for keyword in fungal_keywords):
        return "fungal"
    if any(keyword in label for keyword in bacterial_keywords):
        return "bacterial"
    if any(keyword in label for keyword in viral_keywords):
        return "viral"
    return "unknown"


def _sample(candidates: List[str], count: int = 1) -> List[str]:
    if not candidates or count <= 0:
        return []
    return random.sample(candidates, k=min(count, len(candidates)))


def _dedupe(items: List[str]) -> List[str]:
    seen = set()
    result = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def _has_final_consonant(text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return False

    last_char = stripped[-1]
    code = ord(last_char)
    if not 0xAC00 <= code <= 0xD7A3:
        return False

    return (code - 0xAC00) % 28 != 0


def _with_particle(text: str, with_batchim: str, without_batchim: str) -> str:
    particle = with_batchim if _has_final_consonant(text) else without_batchim
    return f"{text}{particle}"


def _weather_summary(weather: Dict) -> str:
    return (
        f"위치={weather.get('location', 'unknown')}, "
        f"기온={weather.get('temperature_c', 'unknown')}°C, "
        f"습도={weather.get('humidity', 'unknown')}%, "
        f"강수량={weather.get('precipitation_mm', 'unknown')}mm/h, "
        f"날씨={weather.get('weather_description', 'unknown')}, "
        f"일조={weather.get('sunlight_level', 'unknown')}"
    )


def _top_k_summary(result: Dict) -> List[Dict]:
    return [
        {
            "label": item.get("label", item.get("raw_label", "unknown")),
            "confidence_percent": round(float(item.get("confidence", 0.0)) * 100, 2),
        }
        for item in result.get("top_k", [])
    ]


def _fallback_recommendation(
    species_result: Dict,
    disease_result: Dict,
    weather: Dict,
) -> Dict:
    diagnosis: List[str] = []
    actions: List[str] = []

    species_label = species_result.get("label", "unknown")
    disease_label = disease_result.get("label", "unknown")
    disease_conf = float(disease_result.get("confidence", 0.0))

    temp = weather.get("temperature_c")
    humidity = weather.get("humidity")
    precipitation = weather.get("precipitation_mm", 0.0)
    sunlight = weather.get("sunlight_level", "medium")

    category = _disease_category(disease_label)
    species_topic = _with_particle(species_label, "은", "는")
    disease_subject = _with_particle(disease_label, "이", "가")

    if category == "healthy":
        diagnosis.extend(
            _sample(
                [
                    f"현재 모델 기준으로 {species_topic} 정상 상태에 가까워 보입니다.",
                    f"{species_label}에서 뚜렷한 질병 신호는 낮게 예측되었습니다.",
                    f"분류 결과상 {species_topic} 정상 범주로 판단될 가능성이 큽니다.",
                    f"이미지 기준으로는 {species_label}의 잎 상태가 비교적 안정적으로 보입니다.",
                    f"현재 결과만 보면 {species_topic} 급한 병해 대응보다 유지 관리가 우선입니다.",
                ]
            )
        )
    else:
        diagnosis.extend(
            _sample(
                [
                    f"{species_label}에서 {disease_label} 가능성이 감지되었습니다. 모델 신뢰도는 {disease_conf * 100:.1f}%입니다.",
                    f"이번 이미지에서는 {disease_label} 의심 신호가 가장 높게 나타났습니다.",
                    f"{species_label}의 현재 증상은 {disease_label}과 유사한 패턴으로 분류되었습니다.",
                    f"모델은 {disease_label} 쪽으로 판단했지만, 실제 잎 뒷면과 주변 개체도 함께 확인하는 것이 좋습니다.",
                    f"{disease_subject} 의심되므로 같은 작물군의 다른 잎에서도 비슷한 반점이나 변색이 있는지 살펴보세요.",
                ]
            )
        )

        if disease_conf < 0.55:
            diagnosis.extend(
                _sample(
                    [
                        "신뢰도가 높지 않으므로 조명과 초점을 바꿔 한 번 더 촬영해 확인하는 것이 좋습니다.",
                        "예측이 다소 불확실하니 잎 전체와 병반 가까운 사진을 나누어 다시 분석해 보세요.",
                        "사진 조건에 따라 결과가 흔들릴 수 있어, 바로 강한 조치를 하기보다 추가 관찰을 권장합니다.",
                    ]
                )
            )
            actions.extend(
                _sample(
                    [
                        "잎 앞면과 뒷면을 각각 가까이 찍은 뒤 재분석해 결과가 반복되는지 확인하세요.",
                        "흐린 사진이면 밝은 자연광 아래에서 초점을 맞춰 다시 촬영하세요.",
                        "같은 작물의 정상 잎과 의심 잎을 비교해 병반의 모양과 확산 방향을 기록하세요.",
                    ]
                )
            )
        elif disease_conf < 0.75:
            diagnosis.extend(
                _sample(
                    [
                        "중간 수준의 신뢰도이므로 관리 조치는 부드럽게 시작하고 변화 추이를 같이 보세요.",
                        "예측 가능성은 있으나 확정 진단은 아니므로 하루 이틀 간격으로 증상 변화를 확인하세요.",
                    ]
                )
            )

    if humidity is not None and humidity >= 80:
        diagnosis.extend(
            _sample(
                [
                    "습도가 높아 병해가 확산되기 쉬운 환경입니다.",
                    "현재 습도 조건은 곰팡이성 병해가 번지기 좋은 편입니다.",
                    "잎 표면에 물기가 오래 남으면 증상이 빨라질 수 있는 환경입니다.",
                    "공기 흐름이 부족하면 병반이 주변 잎으로 옮겨갈 가능성이 커집니다.",
                ]
            )
        )
        actions.extend(
            _sample(
                [
                    "물 주는 빈도를 줄이고 잎과 토양의 과습을 피하세요.",
                    "환기가 잘되는 위치로 옮기거나 통풍을 확보하세요.",
                    "관수는 되도록 오전에 하고, 잎에 물이 오래 남지 않게 관리하세요.",
                    "화분이나 재배 베드 사이 간격을 조금 벌려 공기 흐름을 만들어 주세요.",
                    "밀폐된 공간이면 짧게라도 환기 시간을 늘려 습기를 빼 주세요.",
                ],
                2,
            )
        )
    elif humidity is not None and humidity >= 70:
        diagnosis.extend(
            _sample(
                [
                    "습도가 다소 높은 편이라 잎이 마르는 속도를 확인할 필요가 있습니다.",
                    "현재 습도에서는 통풍이 부족할 때 병해 위험이 서서히 올라갈 수 있습니다.",
                ]
            )
        )
        actions.extend(
            _sample(
                [
                    "잎 사이가 너무 빽빽하면 일부 잎을 정리해 통풍을 확보하세요.",
                    "저녁 관수는 피하고, 흙 표면이 마른 뒤 물을 주세요.",
                    "환기 팬이나 창문을 활용해 잎 표면의 습기가 빨리 마르게 해 주세요.",
                ]
            )
        )

    if temp is not None and temp <= 10:
        diagnosis.extend(
            _sample(
                [
                    "기온이 낮아 생육 속도가 떨어질 수 있습니다.",
                    "저온 스트레스가 겹치면 회복 속도가 느려질 수 있습니다.",
                    "낮은 온도에서는 뿌리 활력이 줄어 물 흡수가 불안정해질 수 있습니다.",
                ]
            )
        )
        actions.extend(
            _sample(
                [
                    "실내 또는 바람이 적은 따뜻한 곳으로 옮기는 것을 고려하세요.",
                    "찬바람이 직접 닿는 위치라면 차광막보다 보온을 먼저 챙기세요.",
                    "저온일 때는 물을 많이 주기보다 흙 상태를 보고 소량만 주세요.",
                    "야간 온도가 크게 떨어지면 보온 덮개나 위치 조정을 검토하세요.",
                ]
            )
        )

    if temp is not None and temp >= 33:
        diagnosis.extend(
            _sample(
                [
                    "고온 스트레스 가능성이 있습니다.",
                    "높은 온도에서는 잎 처짐과 가장자리 마름이 함께 나타날 수 있습니다.",
                    "한낮 온도가 높으면 병해와 별개로 생리 장해가 겹쳐 보일 수 있습니다.",
                ]
            )
        )
        actions.extend(
            _sample(
                [
                    "직사광선을 완화하고 한낮에는 반그늘에서 관리하세요.",
                    "잎이 축 처지는 시간대를 확인하고, 가장 더운 시간에는 온도 상승을 줄여 주세요.",
                    "토양이 급격히 마르지 않도록 아침 시간에 수분 상태를 확인하세요.",
                    "온실 내부라면 차광과 환기를 함께 적용해 열이 쌓이지 않게 하세요.",
                ]
            )
        )

    if sunlight == "low":
        diagnosis.extend(
            _sample(
                [
                    "일조량이 부족한 환경일 수 있습니다.",
                    "빛이 부족하면 잎 색이 옅어지고 회복력이 떨어질 수 있습니다.",
                    "광량이 낮으면 병해 여부와 별개로 생육이 약해질 가능성이 있습니다.",
                ]
            )
        )
        actions.extend(
            _sample(
                [
                    "하루 3-6시간 이상 밝은 간접광이 드는 위치를 확보하세요.",
                    "그늘진 곳에 있다면 갑자기 강한 빛으로 옮기지 말고 단계적으로 밝기를 높이세요.",
                    "잎이 한쪽으로만 기울면 화분 방향을 주기적으로 돌려 빛을 고르게 받게 하세요.",
                    "보광등을 쓴다면 잎과 너무 가깝지 않게 거리를 확보하세요.",
                ]
            )
        )

    if precipitation is not None and precipitation >= 3:
        actions.extend(
            _sample(
                [
                    "강수량이 높으므로 오늘은 추가 관수를 피하세요.",
                    "비가 온 뒤에는 잎과 줄기 사이에 물이 고이지 않았는지 확인하세요.",
                    "배수가 느린 곳이면 뿌리 과습을 막기 위해 받침 물을 비워 주세요.",
                    "강수 후 병반이 번지는지 24-48시간 안에 다시 확인하세요.",
                ]
            )
        )

    if category != "healthy":
        if category == "fungal":
            actions.extend(
                _sample(
                    [
                        "의심 잎은 가능한 한 건조하게 유지하고 잎 위 물방울을 오래 남기지 마세요.",
                        "병반이 있는 잎을 만진 뒤에는 다른 잎을 만지기 전에 손이나 도구를 깨끗이 닦으세요.",
                        "낙엽이나 병든 잎 조각은 주변에 두지 말고 바로 제거하세요.",
                        "잎이 서로 겹치는 부분을 줄여 병반 주변이 빨리 마르게 해 주세요.",
                    ],
                    2,
                )
            )
        elif category == "viral":
            actions.extend(
                _sample(
                    [
                        "바이러스성 증상이 의심되면 해당 개체를 다른 작물과 분리해 관찰하세요.",
                        "진딧물, 총채벌레 같은 매개충 흔적이 있는지 잎 뒷면을 확인하세요.",
                        "의심 개체를 만진 도구는 다른 작물에 쓰기 전 소독하세요.",
                        "새순의 뒤틀림이나 모자이크 무늬가 계속 늘어나는지 기록하세요.",
                    ],
                    2,
                )
            )
        elif category == "bacterial":
            actions.extend(
                _sample(
                    [
                        "젖은 상태에서 잎을 만지거나 작업하면 증상이 옮기 쉬우니 마른 시간대에 관리하세요.",
                        "의심 부위가 물러지거나 악취가 나는지 확인하고 주변 잎과 접촉을 줄이세요.",
                        "작업 도구는 개체 사이를 이동할 때마다 닦아 주세요.",
                    ],
                    2,
                )
            )
        else:
            actions.extend(
                _sample(
                    [
                        "감염이 의심되는 잎은 다른 작물과 접촉하지 않게 분리하세요.",
                        "의심 부위의 크기와 색 변화를 사진으로 남겨 확산 여부를 확인하세요.",
                        "증상이 있는 잎 주변의 새잎에도 같은 패턴이 나타나는지 살펴보세요.",
                    ],
                    2,
                )
            )
        actions.extend(
            _sample(
                [
                    "증상이 빠르게 확산되면 지역 농업기술센터나 전문가 상담을 권장합니다.",
                    "정확한 처방이 필요하면 작물명, 촬영일, 재배 환경을 함께 정리해 전문가에게 문의하세요.",
                    "심한 잎을 제거할 때는 깨끗한 도구를 사용하고 제거 후 손을 씻어 주세요.",
                    "바로 강한 처치를 하기보다 같은 증상이 반복되는지 하루 정도 추적해 보세요.",
                ],
                2,
            )
        )

    if not actions:
        actions.extend(
            _sample(
                [
                    "현재 환경을 유지하면서 2-3일 간격으로 상태를 확인하세요.",
                    "잎 색, 처짐, 반점 유무를 같은 각도에서 주기적으로 촬영해 비교하세요.",
                    "과습이나 건조가 반복되지 않도록 흙 표면이 마른 뒤 물을 주세요.",
                    "새잎이 정상적으로 나오는지 확인하면 회복 상태를 판단하는 데 도움이 됩니다.",
                    "환기와 적정 광량을 유지하면서 급격한 위치 변경은 피하세요.",
                ],
                2,
            )
        )

    diagnosis = _dedupe(diagnosis)[:4]
    actions = _dedupe(actions)[:6]

    return {
        "plant": species_label,
        "disease_category": category,
        "diagnosis": diagnosis,
        "actions": actions,
        "recommendation_source": "rules",
    }


def _extract_response_text(data: Dict) -> str:
    output_text = data.get("output_text")
    if isinstance(output_text, str) and output_text.strip():
        return output_text

    chunks: List[str] = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            text = content.get("text")
            if isinstance(text, str):
                chunks.append(text)
    return "\n".join(chunks).strip()


def _post_openai_response(payload: Dict, api_key: str) -> Dict:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = request.Request(
        OPENAI_RESPONSES_URL,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"OpenAI API 호출 실패: {exc.code} {detail}") from exc


def _request_ai_recommendation(
    species_result: Dict,
    disease_result: Dict,
    weather: Dict,
    fallback: Dict,
    api_key: str,
    model: str,
) -> Dict:
    species_label = species_result.get("label", "unknown")
    disease_label = disease_result.get("label", "unknown")
    disease_conf = float(disease_result.get("confidence", 0.0)) * 100
    category = fallback["disease_category"]

    prompt = {
        "task": "시설 작물 이미지 분석 결과를 바탕으로 사용자에게 매번 새롭고 구체적인 한국어 관리 피드백을 생성하세요.",
        "constraints": [
            "진단 모델의 예측을 사실처럼 단정하지 말고 '의심', '가능성', '모델 기준'처럼 표현하세요.",
            "농약 상품명, 처방약, 확정 진단은 말하지 마세요.",
            "사용자가 바로 할 수 있는 관찰, 격리, 관수, 환기, 일조, 전문가 상담 중심으로 작성하세요.",
            "과장하지 말고 신뢰도가 낮으면 재촬영 또는 추가 확인을 권하세요.",
            "반드시 JSON만 출력하세요.",
        ],
        "analysis_context": {
            "plant": species_label,
            "disease_or_status": disease_label,
            "disease_category": category,
            "disease_confidence_percent": round(disease_conf, 2),
            "species_confidence_percent": round(float(species_result.get("confidence", 0.0)) * 100, 2),
            "species_top_predictions": _top_k_summary(species_result),
            "disease_top_predictions": _top_k_summary(disease_result),
            "weather": _weather_summary(weather),
            "baseline_rule_recommendation": {
                "diagnosis": fallback["diagnosis"],
                "actions": fallback["actions"],
            },
        },
        "output_shape": {
            "plant": "string",
            "disease_category": "|".join(DISEASE_CATEGORY_VALUES),
            "diagnosis": ["2-3 short Korean sentences"],
            "actions": ["3-5 practical Korean action items"],
        },
    }

    payload = {
        "model": model,
        "instructions": (
            "당신은 시설 작물 관리 보조 AI입니다. "
            "이미지 분류 모델의 결과와 환경 정보를 바탕으로 안전하고 실용적인 한국어 피드백을 작성합니다."
        ),
        "input": json.dumps(prompt, ensure_ascii=False),
        "max_output_tokens": 700,
        "store": False,
        "text": {
            "format": {
                "type": "json_schema",
                "name": "plant_recommendation",
                "strict": True,
                "schema": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "plant": {"type": "string"},
                        "disease_category": {"type": "string", "enum": DISEASE_CATEGORY_VALUES},
                        "diagnosis": {
                            "type": "array",
                            "minItems": 1,
                            "maxItems": 4,
                            "items": {"type": "string"},
                        },
                        "actions": {
                            "type": "array",
                            "minItems": 1,
                            "maxItems": 6,
                            "items": {"type": "string"},
                        },
                    },
                    "required": ["plant", "disease_category", "diagnosis", "actions"],
                },
            }
        },
    }

    content = _extract_response_text(_post_openai_response(payload, api_key))
    generated = json.loads(content)
    generated["recommendation_source"] = "ai"
    return generated


def generate_recommendation(
    species_result: Dict,
    disease_result: Dict,
    weather: Dict,
    use_ai: Optional[bool] = None,
) -> Dict:
    fallback = _fallback_recommendation(species_result, disease_result, weather)
    api_key = os.getenv("OPENAI_API_KEY")
    should_use_ai = bool(api_key) if use_ai is None else use_ai

    if not should_use_ai or not api_key:
        return fallback

    model = os.getenv("OPENAI_RECOMMENDATION_MODEL", DEFAULT_RECOMMENDATION_MODEL)
    try:
        return _request_ai_recommendation(
            species_result=species_result,
            disease_result=disease_result,
            weather=weather,
            fallback=fallback,
            api_key=api_key,
            model=model,
        )
    except (error.URLError, TimeoutError, RuntimeError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        fallback["recommendation_source"] = "rules_fallback"
        fallback["recommendation_error"] = str(exc)
        return fallback
