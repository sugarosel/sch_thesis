param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [ValidateSet("all", "species", "disease")]
    [string]$Target = "all",
    [switch]$SkipManifest,
    [switch]$SkipEval,
    [switch]$Resume,
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if ($Help) {
    Write-Host "Usage:"
    Write-Host "  .\scripts\run_full_training.bat -Target disease"
    Write-Host "  .\scripts\run_full_training.bat -Target species"
    Write-Host "  .\scripts\run_full_training.bat -Target all"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -SkipManifest   Reuse existing data\processed\facility_disease\manifest.csv"
    Write-Host "  -SkipEval       Train only; skip val/test evaluation"
    Write-Host "  -Resume         Continue from models\<target>\last.pt when it exists"
    Write-Host "  -Python PATH    Use a specific Python executable"
    exit 0
}

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

$LogDir = Join-Path $RepoRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogDir "training_$Target`_$Timestamp.log"
Start-Transcript -Path $LogPath -Force | Out-Null

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host "========== $Name =========="
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name"
    }
}

try {
    Write-Host "Repo: $RepoRoot"
    Write-Host "Python: $Python"
    Write-Host "Target: $Target"
    Write-Host "Resume: $Resume"
    Write-Host "Log: $LogPath"

    if (($Target -eq "all" -or $Target -eq "disease") -and -not $SkipManifest) {
        Invoke-Step "Build facility disease manifest" {
            & $Python scripts\build_facility_manifest.py `
                --output_csv data\processed\facility_disease\manifest.csv
        }
    }

    if ($Target -eq "all" -or $Target -eq "species") {
        Invoke-Step "Train PlantNet-300K species model" {
            $args = @("-m", "src.training.train_species", "--config", "configs\species_train.yaml")
            if ($Resume -and (Test-Path -LiteralPath "models\species\last.pt")) {
                $args += @("--resume", "models\species\last.pt")
            }
            & $Python @args
        }

        if (-not $SkipEval) {
            Invoke-Step "Evaluate species model on validation split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\species_train.yaml `
                    --checkpoint models\species\best.pt `
                    --output_dir reports\species_val `
                    --split val
            }

            Invoke-Step "Evaluate species model on test split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\species_train.yaml `
                    --checkpoint models\species\best.pt `
                    --output_dir reports\species_test `
                    --split test
            }
        }
    }

    if ($Target -eq "all" -or $Target -eq "disease") {
        Invoke-Step "Train facility disease model" {
            $args = @("-m", "src.training.train_classifier", "--config", "configs\facility_disease_train.yaml")
            if ($Resume -and (Test-Path -LiteralPath "models\facility_disease\last.pt")) {
                $args += @("--resume", "models\facility_disease\last.pt")
            }
            & $Python @args
        }

        if (-not $SkipEval) {
            Invoke-Step "Evaluate facility disease model on validation split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_disease_train.yaml `
                    --checkpoint models\facility_disease\best.pt `
                    --output_dir reports\facility_disease_val `
                    --split val
            }

            Invoke-Step "Evaluate facility disease model on test split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_disease_train.yaml `
                    --checkpoint models\facility_disease\best.pt `
                    --output_dir reports\facility_disease_test `
                    --split test
            }
        }
    }

    Write-Host ""
    Write-Host "Training run finished."
    Write-Host "Log saved to: $LogPath"
}
finally {
    Stop-Transcript | Out-Null
}
