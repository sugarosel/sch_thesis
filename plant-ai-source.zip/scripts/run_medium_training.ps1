param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [switch]$SkipManifest,
    [switch]$Resume
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

$LogDir = Join-Path $RepoRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogDir "medium_training_disease_$Timestamp.log"
Start-Transcript -Path $LogPath -Force | Out-Null

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host "========== $Name =========="
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name"
    }
}

try {
    Write-Host "Repo: $RepoRoot"
    Write-Host "Python: $Python"
    Write-Host "Log: $LogPath"

    if (-not $SkipManifest) {
        Invoke-Step "Build facility disease manifest" {
            & $Python scripts\build_facility_manifest.py `
                --output_csv data\processed\facility_disease\manifest.csv
        }
    }

    Invoke-Step "Medium train facility disease model" {
        $args = @("-m", "src.training.train_classifier", "--config", "configs\facility_disease_medium.yaml")
        if ($Resume -and (Test-Path -LiteralPath "models\facility_disease_medium\last.pt")) {
            $args += @("--resume", "models\facility_disease_medium\last.pt")
        }
        & $Python @args
    }

    Invoke-Step "Medium evaluate facility disease model on validation split" {
        & $Python -m src.training.evaluate_classifier `
            --config configs\facility_disease_medium.yaml `
            --checkpoint models\facility_disease_medium\best.pt `
            --output_dir reports\facility_disease_medium_val `
            --split val
    }

    Invoke-Step "Medium evaluate facility disease model on test split" {
        & $Python -m src.training.evaluate_classifier `
            --config configs\facility_disease_medium.yaml `
            --checkpoint models\facility_disease_medium\best.pt `
            --output_dir reports\facility_disease_medium_test `
            --split test
    }

    Write-Host ""
    Write-Host "Medium training finished."
    Write-Host "Log saved to: $LogPath"
}
finally {
    Stop-Transcript | Out-Null
}
