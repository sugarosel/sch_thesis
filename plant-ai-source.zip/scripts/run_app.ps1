param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [int]$Port = 8501,
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if ($Help) {
    Write-Host "Usage:"
    Write-Host "  .\scripts\run_app.bat"
    Write-Host "  .\scripts\run_app.bat -Port 8502"
    exit 0
}

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

Write-Host "Starting Plant AI app..."
Write-Host "URL: http://127.0.0.1:$Port"

& $Python -m streamlit run app\streamlit_app.py `
    --server.headless true `
    --server.port $Port `
    --server.address 127.0.0.1
