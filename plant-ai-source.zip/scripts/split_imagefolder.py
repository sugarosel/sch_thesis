import argparse
import random
import shutil
from pathlib import Path


def split_imagefolder(src_dir: Path, out_dir: Path, val_ratio: float, seed: int = 42) -> None:
    random.seed(seed)
    train_root = out_dir / "train"
    val_root = out_dir / "val"
    train_root.mkdir(parents=True, exist_ok=True)
    val_root.mkdir(parents=True, exist_ok=True)

    class_dirs = [p for p in src_dir.iterdir() if p.is_dir()]
    for class_dir in class_dirs:
        images = [p for p in class_dir.iterdir() if p.is_file()]
        random.shuffle(images)
        val_count = int(len(images) * val_ratio)
        val_set = set(images[:val_count])

        (train_root / class_dir.name).mkdir(parents=True, exist_ok=True)
        (val_root / class_dir.name).mkdir(parents=True, exist_ok=True)

        for img in images:
            if img in val_set:
                dst = val_root / class_dir.name / img.name
            else:
                dst = train_root / class_dir.name / img.name
            shutil.copy2(img, dst)

    print(f"Done. train/val created under: {out_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--src_dir", type=str, required=True, help="원본 class 폴더 루트")
    parser.add_argument("--out_dir", type=str, required=True, help="출력 루트(train/val 생성)")
    parser.add_argument("--val_ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    split_imagefolder(Path(args.src_dir), Path(args.out_dir), args.val_ratio, args.seed)
