import argparse

from PIL import Image

from src.inference.pipeline import PlantDiagnosisPipeline
from src.services.recommendation import generate_recommendation
from src.services.weather import fetch_openweather_by_city


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", type=str, required=True)
    parser.add_argument("--config", type=str, default="configs/inference.yaml")
    parser.add_argument("--city", type=str, default="Seoul")
    args = parser.parse_args()

    pipeline = PlantDiagnosisPipeline(config_path=args.config)
    image = Image.open(args.image).convert("RGB")

    pred = pipeline.analyze(image)
    weather = fetch_openweather_by_city(args.city)
    rec = generate_recommendation(pred["species"], pred["disease"], weather)

    print("[Species]", pred["species"])
    print("[Disease]", pred["disease"])
    print("[Weather]", weather)
    print("[Recommendation]", rec)


if __name__ == "__main__":
    main()
