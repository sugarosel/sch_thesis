@echo off
setlocal
cd /d "%~dp0.."
if "%~1"=="-?" goto help
if "%~1"=="/?" goto help
if "%~1"=="--help" goto help
powershell.exe -ExecutionPolicy Bypass -File "%~dp0run_facility_fast_training.ps1" %*
goto end
:help
powershell.exe -ExecutionPolicy Bypass -File "%~dp0run_facility_fast_training.ps1" -Help
:end
endlocal
