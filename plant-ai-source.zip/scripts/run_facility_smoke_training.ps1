param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [switch]$SkipManifest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

$LogDir = Join-Path $RepoRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogDir "facility_smoke_training_$Timestamp.log"
Start-Transcript -Path $LogPath -Force | Out-Null

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host "========== $Name =========="
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name"
    }
}

try {
    Write-Host "Repo: $RepoRoot"
    Write-Host "Python: $Python"
    Write-Host "Log: $LogPath"

    if (-not $SkipManifest) {
        Invoke-Step "Build small 12-crop manifest" {
            & $Python scripts\build_facility_manifest.py `
                --label_mode crop `
                --output_csv data\processed\facility_crop\manifest.csv `
                --max_per_label_train 100 `
                --max_per_label_val 20 `
                --max_per_label_test 20
        }

        Invoke-Step "Build small disease-code manifest" {
            & $Python scripts\build_facility_manifest.py `
                --label_mode disease_code `
                --output_csv data\processed\facility_disease\manifest.csv `
                --max_per_label_train 100 `
                --max_per_label_val 20 `
                --max_per_label_test 20
        }
    }

    Invoke-Step "Smoke train 12-crop classifier" {
        & $Python -m src.training.train_classifier `
            --config configs\facility_crop_smoke.yaml
    }

    Invoke-Step "Smoke evaluate 12-crop classifier on test split" {
        & $Python -m src.training.evaluate_classifier `
            --config configs\facility_crop_smoke.yaml `
            --checkpoint models\facility_crop_smoke\best.pt `
            --output_dir reports\facility_crop_smoke_test `
            --split test
    }

    Invoke-Step "Smoke train disease-code classifier" {
        & $Python -m src.training.train_classifier `
            --config configs\facility_disease_code_smoke.yaml
    }

    Invoke-Step "Smoke evaluate disease-code classifier on test split" {
        & $Python -m src.training.evaluate_classifier `
            --config configs\facility_disease_code_smoke.yaml `
            --checkpoint models\facility_disease_code_smoke\best.pt `
            --output_dir reports\facility_disease_code_smoke_test `
            --split test
    }

    Write-Host ""
    Write-Host "Facility smoke training finished."
    Write-Host "Log saved to: $LogPath"
}
finally {
    Stop-Transcript | Out-Null
}
