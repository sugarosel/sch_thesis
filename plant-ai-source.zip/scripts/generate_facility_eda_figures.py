import os
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import warnings


def set_font() -> None:
    plt.rcParams["font.family"] = ["DejaVu Sans", "Arial", "sans-serif"]
    plt.rcParams["axes.unicode_minus"] = False


def build_dataset() -> pd.DataFrame:
    rows = [
        {"crop": "All", "disease": "Healthy", "count": 204_909, "group": "healthy"},
        {"crop": "Eggplant", "disease": "Eggplant Gray Mold", "count": 7_271, "group": "disease"},
        {"crop": "Eggplant", "disease": "Eggplant Powdery Mildew", "count": 4_057, "group": "disease"},
        {"crop": "Pepper", "disease": "Pepper Mild Mottle Virus", "count": 54_429, "group": "disease"},
        {"crop": "Pepper", "disease": "Pepper Leaf Spot", "count": 9_053, "group": "disease"},
        {"crop": "Kabocha", "disease": "Kabocha Leaf Spot", "count": 10_549, "group": "disease"},
        {"crop": "Kabocha", "disease": "Kabocha Powdery Mildew", "count": 8_537, "group": "disease"},
        {"crop": "Strawberry", "disease": "Strawberry Gray Mold", "count": 12_981, "group": "disease"},
        {"crop": "Strawberry", "disease": "Strawberry Powdery Mildew", "count": 11_950, "group": "disease"},
        {"crop": "Lettuce", "disease": "Lettuce Sclerotinia", "count": 22_234, "group": "disease"},
        {"crop": "Lettuce", "disease": "Lettuce Downy Mildew", "count": 22_793, "group": "disease"},
        {"crop": "Watermelon", "disease": "Watermelon Anthracnose", "count": 10_286, "group": "disease"},
        {"crop": "Watermelon", "disease": "Watermelon Powdery Mildew", "count": 7_518, "group": "disease"},
        {"crop": "Zucchini", "disease": "Zucchini Leaf Spot", "count": 3_278, "group": "disease"},
        {"crop": "Green Pumpkin", "disease": "CGMMV", "count": 22_935, "group": "disease"},
        {"crop": "Cucumber", "disease": "Cucumber Mosaic Virus", "count": 4_411, "group": "disease"},
        {"crop": "Oriental Melon", "disease": "Oriental Melon Downy Mildew", "count": 5_677, "group": "disease"},
        {"crop": "Oriental Melon", "disease": "Oriental Melon Powdery Mildew", "count": 6_017, "group": "disease"},
        {"crop": "Tomato", "disease": "Tomato Leaf Mold", "count": 11_792, "group": "disease"},
        {"crop": "Tomato", "disease": "Tomato Yellow Leaf Curl Virus", "count": 15_246, "group": "disease"},
        {"crop": "Grape", "disease": "Grape Downy Mildew", "count": 2_950, "group": "disease"},
    ]
    return pd.DataFrame(rows)


def save_class_distribution(df: pd.DataFrame, out_dir: Path) -> None:
    plot_df = df.sort_values("count", ascending=False).copy()
    plot_df["label"] = plot_df["disease"]

    plt.figure(figsize=(16, 6))
    ax = sns.barplot(data=plot_df, x="label", y="count", hue="group", dodge=False, palette="Set2")
    ax.set_yscale("log")
    ax.set_title("Class Distribution (Log Scale)")
    ax.set_xlabel("Class")
    ax.set_ylabel("Samples (log)")
    plt.xticks(rotation=75, ha="right")
    plt.tight_layout()
    plt.savefig(out_dir / "eda_class_distribution_log.png", dpi=180)
    plt.close()


def save_healthy_vs_disease(df: pd.DataFrame, out_dir: Path) -> None:
    total = int(df["count"].sum())
    agg = df.groupby("group", as_index=False)["count"].sum()
    agg["ratio"] = agg["count"] / total * 100

    plt.figure(figsize=(7, 5))
    ax = sns.barplot(data=agg, x="group", y="count", hue="group", palette=["#6BAED6", "#FD8D3C"], legend=False)
    ax.set_title("Healthy vs Disease")
    ax.set_xlabel("Group")
    ax.set_ylabel("Samples")
    for i, row in agg.iterrows():
        ax.text(i, row["count"] + total * 0.01, f"{int(row['count']):,}\n({row['ratio']:.1f}%)", ha="center")
    plt.tight_layout()
    plt.savefig(out_dir / "eda_healthy_vs_disease.png", dpi=180)
    plt.close()


def save_crop_disease_distribution(df: pd.DataFrame, out_dir: Path) -> None:
    disease_df = df[df["group"] == "disease"]
    crop_sum = disease_df.groupby("crop", as_index=False)["count"].sum().sort_values("count", ascending=False)

    plt.figure(figsize=(12, 6))
    ax = sns.barplot(data=crop_sum, x="crop", y="count", color="#74C476")
    ax.set_title("Disease Samples by Crop")
    ax.set_xlabel("Crop")
    ax.set_ylabel("Disease Samples")
    for i, row in crop_sum.reset_index(drop=True).iterrows():
        ax.text(i, row["count"] + crop_sum["count"].max() * 0.01, f"{int(row['count']):,}", ha="center", fontsize=9)
    plt.tight_layout()
    plt.savefig(out_dir / "eda_crop_disease_distribution.png", dpi=180)
    plt.close()


def save_top_bottom_disease(df: pd.DataFrame, out_dir: Path) -> None:
    disease_df = df[df["group"] == "disease"].sort_values("count", ascending=False).copy()
    top5 = disease_df.head(5)
    bottom5 = disease_df.tail(5)

    fig, axes = plt.subplots(1, 2, figsize=(16, 5))
    sns.barplot(data=top5, x="count", y="disease", ax=axes[0], color="#3182BD")
    axes[0].set_title("Top 5 Disease Classes")
    axes[0].set_xlabel("Samples")
    axes[0].set_ylabel("")

    sns.barplot(data=bottom5, x="count", y="disease", ax=axes[1], color="#E6550D")
    axes[1].set_title("Bottom 5 Disease Classes")
    axes[1].set_xlabel("Samples")
    axes[1].set_ylabel("")
    plt.tight_layout()
    plt.savefig(out_dir / "eda_top_bottom_disease.png", dpi=180)
    plt.close()


def save_crop_disease_heatmap(df: pd.DataFrame, out_dir: Path) -> None:
    disease_df = df[df["group"] == "disease"].copy()
    pivot = disease_df.pivot_table(index="crop", columns="disease", values="count", fill_value=0, aggfunc="sum")
    pivot = pivot.loc[pivot.sum(axis=1).sort_values(ascending=False).index]

    plt.figure(figsize=(18, 6))
    sns.heatmap(pivot, cmap="YlGnBu", linewidths=0.3, linecolor="white", cbar_kws={"label": "Samples"})
    plt.title("Crop x Disease Heatmap")
    plt.xlabel("Disease")
    plt.ylabel("Crop")
    plt.tight_layout()
    plt.savefig(out_dir / "eda_crop_disease_heatmap.png", dpi=180)
    plt.close()


def save_summary_csv(df: pd.DataFrame, out_dir: Path) -> None:
    total = int(df["count"].sum())
    healthy = int(df[df["group"] == "healthy"]["count"].sum())
    disease = int(df[df["group"] == "disease"]["count"].sum())
    disease_only = df[df["group"] == "disease"]["count"]
    max_cls = int(disease_only.max())
    min_cls = int(disease_only.min())
    ratio = max_cls / min_cls

    summary = pd.DataFrame(
        [
            {"metric": "total_samples", "value": total},
            {"metric": "healthy_samples", "value": healthy},
            {"metric": "disease_samples", "value": disease},
            {"metric": "max_disease_class", "value": max_cls},
            {"metric": "min_disease_class", "value": min_cls},
            {"metric": "max_min_ratio_disease_only", "value": round(ratio, 2)},
        ]
    )
    df.to_csv(out_dir / "facility_dataset_table_from_user_input.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(out_dir / "facility_eda_summary.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    warnings.filterwarnings("ignore", category=UserWarning)
    set_font()
    sns.set_theme(style="whitegrid")

    out_dir = Path("C:/Users/tony_/plant ai/reports/eda_figures")
    os.makedirs(out_dir, exist_ok=True)

    df = build_dataset()
    save_summary_csv(df, out_dir)
    save_class_distribution(df, out_dir)
    save_healthy_vs_disease(df, out_dir)
    save_crop_disease_distribution(df, out_dir)
    save_top_bottom_disease(df, out_dir)
    save_crop_disease_heatmap(df, out_dir)

    print(f"Saved figures to: {out_dir}")


if __name__ == "__main__":
    main()
