import argparse
import csv
import hashlib
import json
import zipfile
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Tuple


SOURCE_DIR = "\uc6d0\ucc9c\ub370\uc774\ud130"
LABEL_DIR = "\ub77c\ubca8\ub9c1\ub370\uc774\ud130"
SPLIT_DIRS = {
    "train": "1.Training",
    "val": "2.Validation",
}


def _is_augmented_zip(path: Path) -> bool:
    return "_9.\uc99d\uac15" in path.name or path.name == "9.\uc99d\uac15.zip"


def _is_supported_source_zip(path: Path, include_aug: bool) -> bool:
    if _is_augmented_zip(path):
        return include_aug
    return (
        "_0.\uc815\uc0c1" in path.name
        or "_1.\uc9c8\ubcd1" in path.name
        or path.name == "1.\uc9c8\ubcd1.zip"
    )


def _iter_files_in_zip(zip_path: Path, suffix: str = "") -> Iterable[zipfile.ZipInfo]:
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            if suffix and not info.filename.lower().endswith(suffix):
                continue
            yield info


def _build_source_index(source_root: Path, include_aug: bool) -> Tuple[Dict[Tuple[str, str], Tuple[str, str]], int]:
    index: Dict[Tuple[str, str], Tuple[str, str]] = {}
    duplicates = 0

    for crop_dir in sorted(p for p in source_root.iterdir() if p.is_dir()):
        for zip_path in sorted(crop_dir.glob("*.zip")):
            if not _is_supported_source_zip(zip_path, include_aug=include_aug):
                continue
            for info in _iter_files_in_zip(zip_path):
                key = (crop_dir.name, Path(info.filename).name)
                if key in index:
                    duplicates += 1
                    continue
                index[key] = (str(zip_path), info.filename)

    return index, duplicates


def _label_from_json(payload: Dict, label_mode: str) -> Tuple[str, int, int]:
    annotations = payload.get("annotations") or {}
    disease_code = int(annotations.get("disease", -1))
    crop_code = int(annotations.get("crop", -1))

    if label_mode == "binary":
        label = "healthy" if disease_code == 0 else "disease"
    elif label_mode == "crop":
        label = f"crop_{crop_code:02d}"
    elif label_mode == "crop_disease":
        label = f"crop_{crop_code:02d}__disease_{disease_code:02d}"
    else:
        label = f"disease_{disease_code:02d}"

    return label, crop_code, disease_code


def _iter_label_rows(
    split: str,
    label_root: Path,
    source_index: Dict[Tuple[str, str], Tuple[str, str]],
    include_aug: bool,
    label_mode: str,
    limit: int,
) -> Tuple[List[Dict], Counter]:
    rows: List[Dict] = []
    stats: Counter = Counter()

    for crop_dir in sorted(p for p in label_root.iterdir() if p.is_dir()):
        for label_zip in sorted(crop_dir.glob("*.zip")):
            is_aug = _is_augmented_zip(label_zip)
            if is_aug and not include_aug:
                continue
            if not is_aug and not (
                "_0.\uc815\uc0c1" in label_zip.name
                or "_1.\uc9c8\ubcd1" in label_zip.name
                or label_zip.name == "1.\uc9c8\ubcd1.zip"
            ):
                continue

            with zipfile.ZipFile(label_zip) as zf:
                for info in zf.infolist():
                    if info.is_dir() or not info.filename.lower().endswith(".json"):
                        continue

                    with zf.open(info) as f:
                        payload = json.load(f)

                    image_name = payload.get("description", {}).get("image")
                    if not image_name:
                        image_name = Path(info.filename).name[:-5]

                    source = source_index.get((crop_dir.name, Path(image_name).name))
                    if source is None:
                        stats["missing_source"] += 1
                        continue

                    label, crop_code, disease_code = _label_from_json(payload, label_mode=label_mode)
                    image_zip, image_member = source
                    rows.append(
                        {
                            "split": split,
                            "crop": crop_dir.name,
                            "crop_code": crop_code,
                            "disease_code": disease_code,
                            "label": label,
                            "image_zip": image_zip,
                            "image_member": image_member,
                            "label_zip": str(label_zip),
                            "label_member": info.filename,
                            "is_aug": int(is_aug),
                        }
                    )
                    stats[f"label:{label}"] += 1

                    if limit > 0 and len(rows) >= limit:
                        return rows, stats

    return rows, stats


def build_manifest(
    dataset_root: Path,
    output_csv: Path,
    label_mode: str,
    include_train_aug: bool,
    include_val_aug: bool,
    official_val_as_test: bool,
    val_ratio_from_train: float,
    test_ratio_from_val: float,
    max_per_label_train: int,
    max_per_label_val: int,
    max_per_label_test: int,
    limit_per_split: int,
) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)

    all_rows: List[Dict] = []
    total_stats: Counter = Counter()

    for split, split_dir in SPLIT_DIRS.items():
        split_root = dataset_root / split_dir
        source_root = split_root / SOURCE_DIR
        label_root = split_root / LABEL_DIR
        include_aug = include_train_aug if split == "train" else include_val_aug

        source_index, duplicates = _build_source_index(source_root, include_aug=include_aug)
        rows, stats = _iter_label_rows(
            split=split,
            label_root=label_root,
            source_index=source_index,
            include_aug=include_aug,
            label_mode=label_mode,
            limit=limit_per_split,
        )
        all_rows.extend(rows)
        total_stats.update({f"raw_{k}": v for k, v in stats.items()})
        total_stats[f"raw_{split}_rows"] += len(rows)
        total_stats[f"{split}_source_duplicates"] += duplicates

    if official_val_as_test:
        for row in all_rows:
            if row["split"] == "val":
                row["split"] = "test"
        if val_ratio_from_train > 0:
            _move_rows_between_splits(all_rows, "train", "val", val_ratio_from_train)
    elif test_ratio_from_val > 0:
        _move_rows_between_splits(all_rows, "val", "test", test_ratio_from_val)

    all_rows = _cap_rows_per_split_label(
        all_rows,
        {
            "train": max_per_label_train,
            "val": max_per_label_val,
            "test": max_per_label_test,
        },
    )

    total_stats.update(_summarize_rows(all_rows))

    fieldnames = [
        "split",
        "crop",
        "crop_code",
        "disease_code",
        "label",
        "image_zip",
        "image_member",
        "label_zip",
        "label_member",
        "is_aug",
    ]
    with output_csv.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)

    summary_path = output_csv.with_suffix(".summary.json")
    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(total_stats, f, ensure_ascii=False, indent=2)

    print(f"Wrote {len(all_rows):,} rows to {output_csv}")
    print(f"Wrote summary to {summary_path}")


def _stable_score(row: Dict) -> float:
    key = "|".join(
        [
            str(row.get("label", "")),
            str(row.get("crop", "")),
            str(row.get("image_zip", "")),
            str(row.get("image_member", "")),
        ]
    )
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()
    return int(digest[:12], 16) / float(0xFFFFFFFFFFFF)


def _move_rows_between_splits(rows: List[Dict], source_split: str, target_split: str, ratio: float) -> None:
    if not 0 <= ratio < 1:
        raise ValueError("Split ratio must be >= 0 and < 1")

    by_label: Dict[str, List[Dict]] = {}
    for row in rows:
        if row["split"] != source_split:
            continue
        by_label.setdefault(row["label"], []).append(row)

    for label_rows in by_label.values():
        if len(label_rows) <= 1:
            continue
        move_count = int(round(len(label_rows) * ratio))
        move_count = max(1, min(move_count, len(label_rows) - 1))
        for row in sorted(label_rows, key=_stable_score)[:move_count]:
            row["split"] = target_split


def _cap_rows_per_split_label(rows: List[Dict], caps: Dict[str, int]) -> List[Dict]:
    if all(cap <= 0 for cap in caps.values()):
        return rows

    grouped: Dict[Tuple[str, str], List[Dict]] = {}
    for row in rows:
        grouped.setdefault((row["split"], row["label"]), []).append(row)

    kept: List[Dict] = []
    for (split, _label), label_rows in grouped.items():
        cap = int(caps.get(split, 0) or 0)
        if cap <= 0 or len(label_rows) <= cap:
            kept.extend(label_rows)
            continue
        kept.extend(sorted(label_rows, key=_stable_score)[:cap])

    return sorted(kept, key=lambda row: (row["split"], row["label"], _stable_score(row)))


def _summarize_rows(rows: List[Dict]) -> Counter:
    stats: Counter = Counter()
    for row in rows:
        split = row["split"]
        label = row["label"]
        stats[f"{split}_rows"] += 1
        stats[f"{split}_label:{label}"] += 1
    return stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset_root",
        default=(
            "D:\\plant ai\\071.\uc2dc\uc124 \uc791\ubb3c "
            "\uc9c8\ubcd1 \uc9c4\ub2e8\\01.\ub370\uc774\ud130"
        ),
        help="Root containing 1.Training and 2.Validation.",
    )
    parser.add_argument(
        "--output_csv",
        default="data/processed/facility_disease/manifest.csv",
    )
    parser.add_argument(
        "--label_mode",
        choices=["disease_code", "crop_disease", "binary", "crop"],
        default="disease_code",
    )
    parser.add_argument("--include_train_aug", action="store_true")
    parser.add_argument("--include_val_aug", action="store_true")
    parser.add_argument(
        "--official_val_as_test",
        dest="official_val_as_test",
        action="store_true",
        default=True,
        help="Use 2.Validation as final test and split validation rows from 1.Training.",
    )
    parser.add_argument(
        "--no_official_val_as_test",
        dest="official_val_as_test",
        action="store_false",
    )
    parser.add_argument(
        "--val_ratio_from_train",
        type=float,
        default=0.15,
        help="When official_val_as_test is enabled, move this ratio of train rows to split=val.",
    )
    parser.add_argument(
        "--test_ratio_from_val",
        type=float,
        default=0.0,
        help="When official_val_as_test is disabled, move this ratio of 2.Validation rows to split=test.",
    )
    parser.add_argument("--limit_per_split", type=int, default=0)
    parser.add_argument("--max_per_label_train", type=int, default=0)
    parser.add_argument("--max_per_label_val", type=int, default=0)
    parser.add_argument("--max_per_label_test", type=int, default=0)
    args = parser.parse_args()

    build_manifest(
        dataset_root=Path(args.dataset_root),
        output_csv=Path(args.output_csv),
        label_mode=args.label_mode,
        include_train_aug=args.include_train_aug,
        include_val_aug=args.include_val_aug,
        official_val_as_test=args.official_val_as_test,
        val_ratio_from_train=args.val_ratio_from_train,
        test_ratio_from_val=args.test_ratio_from_val,
        max_per_label_train=args.max_per_label_train,
        max_per_label_val=args.max_per_label_val,
        max_per_label_test=args.max_per_label_test,
        limit_per_split=args.limit_per_split,
    )


if __name__ == "__main__":
    main()
