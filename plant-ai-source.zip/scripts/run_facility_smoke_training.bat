@echo off
setlocal
cd /d "%~dp0.."
powershell.exe -ExecutionPolicy Bypass -File "%~dp0run_facility_smoke_training.ps1" %*
endlocal
