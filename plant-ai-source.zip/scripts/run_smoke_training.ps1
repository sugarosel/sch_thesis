param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [ValidateSet("all", "species", "disease")]
    [string]$Target = "disease",
    [switch]$SkipManifest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

$LogDir = Join-Path $RepoRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogDir "smoke_training_$Target`_$Timestamp.log"
Start-Transcript -Path $LogPath -Force | Out-Null

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host "========== $Name =========="
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name"
    }
}

try {
    Write-Host "Repo: $RepoRoot"
    Write-Host "Python: $Python"
    Write-Host "Target: $Target"
    Write-Host "Log: $LogPath"

    if (($Target -eq "all" -or $Target -eq "disease") -and -not $SkipManifest) {
        Invoke-Step "Build facility disease manifest" {
            & $Python scripts\build_facility_manifest.py `
                --output_csv data\processed\facility_disease\manifest.csv
        }
    }

    if ($Target -eq "all" -or $Target -eq "disease") {
        Invoke-Step "Smoke train facility disease model" {
            & $Python -m src.training.train_classifier `
                --config configs\facility_disease_smoke.yaml
        }

        Invoke-Step "Smoke evaluate facility disease model on validation split" {
            & $Python -m src.training.evaluate_classifier `
                --config configs\facility_disease_smoke.yaml `
                --checkpoint models\facility_disease_smoke\best.pt `
                --output_dir reports\facility_disease_smoke_val `
                --split val
        }

        Invoke-Step "Smoke evaluate facility disease model on test split" {
            & $Python -m src.training.evaluate_classifier `
                --config configs\facility_disease_smoke.yaml `
                --checkpoint models\facility_disease_smoke\best.pt `
                --output_dir reports\facility_disease_smoke_test `
                --split test
        }
    }

    if ($Target -eq "all" -or $Target -eq "species") {
        Invoke-Step "Smoke train PlantNet-300K species model" {
            & $Python -m src.training.train_species `
                --config configs\species_smoke.yaml
        }

        Invoke-Step "Smoke evaluate species model on validation split" {
            & $Python -m src.training.evaluate_classifier `
                --config configs\species_smoke.yaml `
                --checkpoint models\species_smoke\best.pt `
                --output_dir reports\species_smoke_val `
                --split val
        }

        Invoke-Step "Smoke evaluate species model on test split" {
            & $Python -m src.training.evaluate_classifier `
                --config configs\species_smoke.yaml `
                --checkpoint models\species_smoke\best.pt `
                --output_dir reports\species_smoke_test `
                --split test
        }
    }

    Write-Host ""
    Write-Host "Smoke training finished."
    Write-Host "Log saved to: $LogPath"
}
finally {
    Stop-Transcript | Out-Null
}
