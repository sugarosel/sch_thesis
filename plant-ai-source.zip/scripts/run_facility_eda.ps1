$env:PYTHONPATH = "C:\Users\tony_\plant ai\.pylibs"
& "C:\Users\tony_\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" `
  "C:\Users\tony_\plant ai\scripts\generate_facility_eda_figures.py"
