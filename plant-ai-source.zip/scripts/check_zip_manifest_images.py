import argparse
import csv
import json
import zipfile
import zlib
from pathlib import Path
from typing import Dict, Tuple

import pandas as pd
from PIL import Image, UnidentifiedImageError


def _check_image(zip_cache: Dict[str, zipfile.ZipFile], zip_path: str, member: str) -> Tuple[bool, str]:
    try:
        if zip_path not in zip_cache:
            zip_cache[zip_path] = zipfile.ZipFile(zip_path)

        with zip_cache[zip_path].open(member) as f:
            with Image.open(f) as image:
                image.verify()
        return True, ""
    except (
        FileNotFoundError,
        KeyError,
        OSError,
        UnidentifiedImageError,
        zipfile.BadZipFile,
        zlib.error,
    ) as exc:
        return False, f"{type(exc).__name__}: {exc}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", default="data/processed/facility_disease/manifest.csv")
    parser.add_argument("--output_bad_csv", default="reports/facility_disease_bad_images.csv")
    parser.add_argument("--output_summary", default="reports/facility_disease_bad_images_summary.json")
    parser.add_argument("--limit", type=int, default=0, help="Check only the first N rows. 0 means all rows.")
    parser.add_argument("--progress_every", type=int, default=5000)
    args = parser.parse_args()

    df = pd.read_csv(args.manifest)
    if args.limit > 0:
        df = df.head(args.limit)

    output_bad_csv = Path(args.output_bad_csv)
    output_bad_csv.parent.mkdir(parents=True, exist_ok=True)
    output_summary = Path(args.output_summary)
    output_summary.parent.mkdir(parents=True, exist_ok=True)

    zip_cache: Dict[str, zipfile.ZipFile] = {}
    bad_rows = []

    try:
        for i, row in df.iterrows():
            ok, error = _check_image(zip_cache, str(row["image_zip"]), str(row["image_member"]))
            if not ok:
                bad_rows.append(
                    {
                        "row_index": int(i),
                        "split": row.get("split"),
                        "label": row.get("label"),
                        "crop": row.get("crop"),
                        "image_zip": row.get("image_zip"),
                        "image_member": row.get("image_member"),
                        "error": error,
                    }
                )

            checked = i + 1
            if args.progress_every > 0 and checked % args.progress_every == 0:
                print(f"checked={checked:,}, bad={len(bad_rows):,}")
    finally:
        for zf in zip_cache.values():
            zf.close()

    with output_bad_csv.open("w", encoding="utf-8-sig", newline="") as f:
        fieldnames = ["row_index", "split", "label", "crop", "image_zip", "image_member", "error"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(bad_rows)

    summary = {
        "manifest": args.manifest,
        "checked_rows": int(len(df)),
        "bad_rows": len(bad_rows),
        "bad_ratio": (len(bad_rows) / len(df)) if len(df) else 0.0,
        "output_bad_csv": str(output_bad_csv),
    }
    with output_summary.open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
