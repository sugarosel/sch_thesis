param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [ValidateSet("all", "crop", "disease")]
    [string]$Target = "all",
    [switch]$SkipManifest,
    [switch]$SkipEval,
    [switch]$Resume,
    [int]$CropMaxTrain = 3000,
    [int]$CropMaxVal = 500,
    [int]$CropMaxTest = 500,
    [int]$DiseaseMaxTrain = 3000,
    [int]$DiseaseMaxVal = 500,
    [int]$DiseaseMaxTest = 500,
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

if ($Help) {
    Write-Host "Usage:"
    Write-Host "  .\scripts\run_facility_training.bat -Target all"
    Write-Host "  .\scripts\run_facility_training.bat -Target crop"
    Write-Host "  .\scripts\run_facility_training.bat -Target disease"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -SkipManifest   Reuse existing facility crop/disease manifests"
    Write-Host "  -SkipEval       Train only; skip val/test evaluation"
    Write-Host "  -Resume         Continue from last.pt when it exists"
    Write-Host "  -CropMaxTrain N, -DiseaseMaxTrain N   Per-label train caps"
    exit 0
}

$LogDir = Join-Path $RepoRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogDir "facility_training_$Target`_$Timestamp.log"
Start-Transcript -Path $LogPath -Force | Out-Null

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host "========== $Name =========="
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name"
    }
}

try {
    Write-Host "Repo: $RepoRoot"
    Write-Host "Python: $Python"
    Write-Host "Target: $Target"
    Write-Host "Resume: $Resume"
    Write-Host "Log: $LogPath"

    if (($Target -eq "all" -or $Target -eq "crop") -and -not $SkipManifest) {
        Invoke-Step "Build 12-crop manifest from facility dataset" {
            & $Python scripts\build_facility_manifest.py `
                --label_mode crop `
                --output_csv data\processed\facility_crop\manifest.csv `
                --max_per_label_train $CropMaxTrain `
                --max_per_label_val $CropMaxVal `
                --max_per_label_test $CropMaxTest
        }
    }

    if (($Target -eq "all" -or $Target -eq "disease") -and -not $SkipManifest) {
        Invoke-Step "Build disease-code manifest from facility dataset" {
            & $Python scripts\build_facility_manifest.py `
                --label_mode disease_code `
                --output_csv data\processed\facility_disease\manifest.csv `
                --max_per_label_train $DiseaseMaxTrain `
                --max_per_label_val $DiseaseMaxVal `
                --max_per_label_test $DiseaseMaxTest
        }
    }

    if ($Target -eq "all" -or $Target -eq "crop") {
        Invoke-Step "Train 12-crop classifier" {
            $args = @("-m", "src.training.train_classifier", "--config", "configs\facility_crop_train.yaml")
            if ($Resume -and (Test-Path -LiteralPath "models\facility_crop\last.pt")) {
                $args += @("--resume", "models\facility_crop\last.pt")
            }
            & $Python @args
        }

        if (-not $SkipEval) {
            Invoke-Step "Evaluate 12-crop classifier on validation split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_crop_train.yaml `
                    --checkpoint models\facility_crop\best.pt `
                    --output_dir reports\facility_crop_val `
                    --split val
            }

            Invoke-Step "Evaluate 12-crop classifier on test split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_crop_train.yaml `
                    --checkpoint models\facility_crop\best.pt `
                    --output_dir reports\facility_crop_test `
                    --split test
            }
        }
    }

    if ($Target -eq "all" -or $Target -eq "disease") {
        Invoke-Step "Train disease-code classifier" {
            $args = @("-m", "src.training.train_classifier", "--config", "configs\facility_disease_train.yaml")
            if ($Resume -and (Test-Path -LiteralPath "models\facility_disease\last.pt")) {
                $args += @("--resume", "models\facility_disease\last.pt")
            }
            & $Python @args
        }

        if (-not $SkipEval) {
            Invoke-Step "Evaluate disease-code classifier on validation split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_disease_train.yaml `
                    --checkpoint models\facility_disease\best.pt `
                    --output_dir reports\facility_disease_val `
                    --split val
            }

            Invoke-Step "Evaluate disease-code classifier on test split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_disease_train.yaml `
                    --checkpoint models\facility_disease\best.pt `
                    --output_dir reports\facility_disease_test `
                    --split test
            }
        }
    }

    Write-Host ""
    Write-Host "Facility-only training finished."
    Write-Host "Log saved to: $LogPath"
}
finally {
    Stop-Transcript | Out-Null
}
