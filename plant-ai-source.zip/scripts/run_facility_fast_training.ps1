param(
    [string]$Python = "C:\Users\tony_\anaconda3\python.exe",
    [ValidateSet("all", "crop", "disease")]
    [string]$Target = "all",
    [switch]$SkipManifest,
    [switch]$SkipEval,
    [switch]$Resume,
    [int]$CropMaxTrain = 1000,
    [int]$CropMaxVal = 300,
    [int]$CropMaxTest = 300,
    [int]$DiseaseMaxTrain = 1000,
    [int]$DiseaseMaxVal = 300,
    [int]$DiseaseMaxTest = 300,
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location -LiteralPath $RepoRoot

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python executable not found: $Python"
}

if ($Help) {
    Write-Host "Usage:"
    Write-Host "  .\scripts\run_facility_fast_training.bat -Target all"
    Write-Host "  .\scripts\run_facility_fast_training.bat -Target crop"
    Write-Host "  .\scripts\run_facility_fast_training.bat -Target disease"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -SkipManifest   Reuse existing fast manifests"
    Write-Host "  -SkipEval       Train only; skip val/test evaluation"
    Write-Host "  -Resume         Continue from fast last.pt when it exists"
    Write-Host "  -CropMaxTrain N, -DiseaseMaxTrain N   Per-label train caps"
    exit 0
}

$LogDir = Join-Path $RepoRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogPath = Join-Path $LogDir "facility_fast_training_$Target`_$Timestamp.log"
Start-Transcript -Path $LogPath -Force | Out-Null

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host "========== $Name =========="
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Name"
    }
}

try {
    Write-Host "Repo: $RepoRoot"
    Write-Host "Python: $Python"
    Write-Host "Target: $Target"
    Write-Host "Resume: $Resume"
    Write-Host "Crop caps: train=$CropMaxTrain val=$CropMaxVal test=$CropMaxTest per class"
    Write-Host "Disease caps: train=$DiseaseMaxTrain val=$DiseaseMaxVal test=$DiseaseMaxTest per class"
    Write-Host "Log: $LogPath"

    if (($Target -eq "all" -or $Target -eq "crop") -and -not $SkipManifest) {
        Invoke-Step "Build fast 12-crop manifest" {
            & $Python scripts\build_facility_manifest.py `
                --label_mode crop `
                --output_csv data\processed\facility_crop_fast\manifest.csv `
                --max_per_label_train $CropMaxTrain `
                --max_per_label_val $CropMaxVal `
                --max_per_label_test $CropMaxTest
        }
    }

    if (($Target -eq "all" -or $Target -eq "disease") -and -not $SkipManifest) {
        Invoke-Step "Build fast disease-code manifest" {
            & $Python scripts\build_facility_manifest.py `
                --label_mode disease_code `
                --output_csv data\processed\facility_disease_fast\manifest.csv `
                --max_per_label_train $DiseaseMaxTrain `
                --max_per_label_val $DiseaseMaxVal `
                --max_per_label_test $DiseaseMaxTest
        }
    }

    if ($Target -eq "all" -or $Target -eq "crop") {
        Invoke-Step "Train fast 12-crop classifier" {
            $args = @("-m", "src.training.train_classifier", "--config", "configs\facility_crop_fast.yaml")
            if ($Resume -and (Test-Path -LiteralPath "models\facility_crop_fast\last.pt")) {
                $args += @("--resume", "models\facility_crop_fast\last.pt")
            }
            & $Python @args
        }

        if (-not $SkipEval) {
            Invoke-Step "Evaluate fast 12-crop classifier on validation split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_crop_fast.yaml `
                    --checkpoint models\facility_crop_fast\best.pt `
                    --output_dir reports\facility_crop_fast_val `
                    --split val
            }

            Invoke-Step "Evaluate fast 12-crop classifier on test split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_crop_fast.yaml `
                    --checkpoint models\facility_crop_fast\best.pt `
                    --output_dir reports\facility_crop_fast_test `
                    --split test
            }
        }
    }

    if ($Target -eq "all" -or $Target -eq "disease") {
        Invoke-Step "Train fast disease-code classifier" {
            $args = @("-m", "src.training.train_classifier", "--config", "configs\facility_disease_fast.yaml")
            if ($Resume -and (Test-Path -LiteralPath "models\facility_disease_fast\last.pt")) {
                $args += @("--resume", "models\facility_disease_fast\last.pt")
            }
            & $Python @args
        }

        if (-not $SkipEval) {
            Invoke-Step "Evaluate fast disease-code classifier on validation split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_disease_fast.yaml `
                    --checkpoint models\facility_disease_fast\best.pt `
                    --output_dir reports\facility_disease_fast_val `
                    --split val
            }

            Invoke-Step "Evaluate fast disease-code classifier on test split" {
                & $Python -m src.training.evaluate_classifier `
                    --config configs\facility_disease_fast.yaml `
                    --checkpoint models\facility_disease_fast\best.pt `
                    --output_dir reports\facility_disease_fast_test `
                    --split test
            }
        }
    }

    Write-Host ""
    Write-Host "Fast facility training finished."
    Write-Host "Log saved to: $LogPath"
}
finally {
    Stop-Transcript | Out-Null
}
